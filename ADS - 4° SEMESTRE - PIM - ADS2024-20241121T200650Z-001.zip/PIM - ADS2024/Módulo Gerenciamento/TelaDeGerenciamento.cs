﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM_DESKTOP_TESTE01
{
    public partial class TelaDeGerenciamento : Form
    {
        public TelaDeGerenciamento()
        {
            InitializeComponent();
        }

        private void TelaDeGerenciamento_Load(object sender, EventArgs e)
        {
        }

        private void btnVoltarTelaInicial_Click(object sender, EventArgs e)
        {
            TelaInicial telaInicial = new TelaInicial();
            telaInicial.WindowState = FormWindowState.Maximized;
            telaInicial.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            telaInicial.Show();

            this.FormClosed += (s, args) => telaInicial.Show();
        }

        private void lblControleDeEstoque_Click(object sender, EventArgs e)
        {

        }

        private void btnControleDeEstoque_Click(object sender, EventArgs e)
        {
            ControledeEstoque controleDeEstoque = new ControledeEstoque();
            controleDeEstoque.WindowState = FormWindowState.Maximized;
            controleDeEstoque.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            controleDeEstoque.Show();


            this.FormClosed += (s, args) => controleDeEstoque.Show();
        }

        private void btnRelatoriosDeGestao_Click(object sender, EventArgs e)
        {
            RelatóriosDeGestão relatoriosDeGestao = new RelatóriosDeGestão();
            relatoriosDeGestao.WindowState = FormWindowState.Maximized;
            relatoriosDeGestao.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            relatoriosDeGestao.Show();

            this.FormClosed += (s, args) => relatoriosDeGestao.Show();
        }
        private void btnGerenciarProduto_Click(object sender, EventArgs e)
        {
            GerenciarProduto gerenciarProduto = new GerenciarProduto();
            gerenciarProduto.WindowState = FormWindowState.Maximized;
            gerenciarProduto.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            gerenciarProduto.Show();

            this.FormClosed += (s, args) => gerenciarProduto.Show();

        }
        private void button1_Click(object sender, EventArgs e)
        {
           ControledeEstoque controledeEstoque = new ControledeEstoque();
           controledeEstoque.Show();
        }

        private void lblAlertas1_Click(object sender, EventArgs e)
        {

        }

        private void lblTextoVoltarTelaInicial_Click(object sender, EventArgs e)
        {

        }

        private void lblGerenciamento_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ControledeEstoque controledeEstoque = new ControledeEstoque();
            controledeEstoque.WindowState = FormWindowState.Maximized;
            controledeEstoque.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            controledeEstoque.Show();

            this.FormClosed += (s, args) => controledeEstoque.Show();
        }
    }
}
