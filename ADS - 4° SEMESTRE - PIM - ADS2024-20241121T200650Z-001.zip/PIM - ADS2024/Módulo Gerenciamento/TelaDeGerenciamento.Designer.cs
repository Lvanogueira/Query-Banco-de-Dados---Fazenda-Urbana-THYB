﻿namespace PIM_DESKTOP_TESTE01
{
    partial class TelaDeGerenciamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGerenciamento = new System.Windows.Forms.Label();
            this.lblFundoGerenciamento = new System.Windows.Forms.Label();
            this.lblAlertas1 = new System.Windows.Forms.Label();
            this.lblFundoAlertas = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAlertas = new System.Windows.Forms.Button();
            this.btnRelatoriosDeGestao = new System.Windows.Forms.Button();
            this.btnControleDeEstoque = new System.Windows.Forms.Button();
            this.btnGerenciarProduto = new System.Windows.Forms.Button();
            this.btnVoltarTelaInicial = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblGerenciamento
            // 
            this.lblGerenciamento.BackColor = System.Drawing.Color.SeaGreen;
            this.lblGerenciamento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGerenciamento.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblGerenciamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGerenciamento.ForeColor = System.Drawing.Color.White;
            this.lblGerenciamento.Location = new System.Drawing.Point(730, 352);
            this.lblGerenciamento.Name = "lblGerenciamento";
            this.lblGerenciamento.Size = new System.Drawing.Size(556, 105);
            this.lblGerenciamento.TabIndex = 1;
            this.lblGerenciamento.Text = "Gerenciamento";
            this.lblGerenciamento.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblGerenciamento.Click += new System.EventHandler(this.lblGerenciamento_Click);
            // 
            // lblFundoGerenciamento
            // 
            this.lblFundoGerenciamento.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundoGerenciamento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFundoGerenciamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoGerenciamento.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblFundoGerenciamento.Location = new System.Drawing.Point(571, 258);
            this.lblFundoGerenciamento.Name = "lblFundoGerenciamento";
            this.lblFundoGerenciamento.Size = new System.Drawing.Size(851, 606);
            this.lblFundoGerenciamento.TabIndex = 11;
            // 
            // lblAlertas1
            // 
            this.lblAlertas1.BackColor = System.Drawing.Color.SeaGreen;
            this.lblAlertas1.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlertas1.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblAlertas1.Location = new System.Drawing.Point(1626, 80);
            this.lblAlertas1.Name = "lblAlertas1";
            this.lblAlertas1.Size = new System.Drawing.Size(347, 49);
            this.lblAlertas1.TabIndex = 14;
            this.lblAlertas1.Text = "Alerta!";
            this.lblAlertas1.Click += new System.EventHandler(this.lblAlertas1_Click);
            // 
            // lblFundoAlertas
            // 
            this.lblFundoAlertas.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundoAlertas.Location = new System.Drawing.Point(1616, 76);
            this.lblFundoAlertas.Name = "lblFundoAlertas";
            this.lblFundoAlertas.Size = new System.Drawing.Size(497, 97);
            this.lblFundoAlertas.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SeaGreen;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(1614, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(435, 58);
            this.label1.TabIndex = 15;
            this.label1.Text = "Alguns produtos podem estar acabando, solicite agora a reposição!";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnAlertas
            // 
            this.btnAlertas.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAlertas.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAlertas.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.warning_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnAlertas.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAlertas.Location = new System.Drawing.Point(1602, 68);
            this.btnAlertas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAlertas.Name = "btnAlertas";
            this.btnAlertas.Size = new System.Drawing.Size(533, 113);
            this.btnAlertas.TabIndex = 12;
            this.btnAlertas.UseVisualStyleBackColor = false;
            this.btnAlertas.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRelatoriosDeGestao
            // 
            this.btnRelatoriosDeGestao.BackColor = System.Drawing.Color.White;
            this.btnRelatoriosDeGestao.Font = new System.Drawing.Font("Nirmala UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatoriosDeGestao.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.bar_chart_4_bars_16dp_000000_FILL0_wght400_GRAD0_opsz20_1_;
            this.btnRelatoriosDeGestao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRelatoriosDeGestao.Location = new System.Drawing.Point(614, 717);
            this.btnRelatoriosDeGestao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRelatoriosDeGestao.Name = "btnRelatoriosDeGestao";
            this.btnRelatoriosDeGestao.Size = new System.Drawing.Size(759, 79);
            this.btnRelatoriosDeGestao.TabIndex = 9;
            this.btnRelatoriosDeGestao.Text = "Relatórios de Gestão";
            this.btnRelatoriosDeGestao.UseVisualStyleBackColor = false;
            this.btnRelatoriosDeGestao.Click += new System.EventHandler(this.btnRelatoriosDeGestao_Click);
            // 
            // btnControleDeEstoque
            // 
            this.btnControleDeEstoque.BackColor = System.Drawing.Color.White;
            this.btnControleDeEstoque.Font = new System.Drawing.Font("Nirmala UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnControleDeEstoque.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.inventory_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnControleDeEstoque.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnControleDeEstoque.Location = new System.Drawing.Point(614, 603);
            this.btnControleDeEstoque.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnControleDeEstoque.Name = "btnControleDeEstoque";
            this.btnControleDeEstoque.Size = new System.Drawing.Size(759, 79);
            this.btnControleDeEstoque.TabIndex = 5;
            this.btnControleDeEstoque.Text = "Controle de Estoque";
            this.btnControleDeEstoque.UseVisualStyleBackColor = false;
            this.btnControleDeEstoque.Click += new System.EventHandler(this.btnControleDeEstoque_Click);
            // 
            // btnGerenciarProduto
            // 
            this.btnGerenciarProduto.BackColor = System.Drawing.Color.White;
            this.btnGerenciarProduto.Font = new System.Drawing.Font("Nirmala UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGerenciarProduto.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.box_edit_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnGerenciarProduto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGerenciarProduto.Location = new System.Drawing.Point(614, 499);
            this.btnGerenciarProduto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGerenciarProduto.Name = "btnGerenciarProduto";
            this.btnGerenciarProduto.Size = new System.Drawing.Size(759, 79);
            this.btnGerenciarProduto.TabIndex = 5;
            this.btnGerenciarProduto.Text = "Gerenciar Produto";
            this.btnGerenciarProduto.UseVisualStyleBackColor = false;
            this.btnGerenciarProduto.Click += new System.EventHandler(this.btnGerenciarProduto_Click);
            // 
            // btnVoltarTelaInicial
            // 
            this.btnVoltarTelaInicial.BackColor = System.Drawing.Color.SeaGreen;
            this.btnVoltarTelaInicial.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltarTelaInicial.ForeColor = System.Drawing.Color.White;
            this.btnVoltarTelaInicial.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.home_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnVoltarTelaInicial.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVoltarTelaInicial.Location = new System.Drawing.Point(0, 62);
            this.btnVoltarTelaInicial.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVoltarTelaInicial.Name = "btnVoltarTelaInicial";
            this.btnVoltarTelaInicial.Size = new System.Drawing.Size(429, 97);
            this.btnVoltarTelaInicial.TabIndex = 2;
            this.btnVoltarTelaInicial.Text = "Voltar para a Tela Inicial.";
            this.btnVoltarTelaInicial.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVoltarTelaInicial.UseVisualStyleBackColor = false;
            this.btnVoltarTelaInicial.Click += new System.EventHandler(this.btnVoltarTelaInicial_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1605, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(404, 110);
            this.button1.TabIndex = 16;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // TelaDeGerenciamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1924, 1045);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblAlertas1);
            this.Controls.Add(this.btnAlertas);
            this.Controls.Add(this.lblFundoAlertas);
            this.Controls.Add(this.btnRelatoriosDeGestao);
            this.Controls.Add(this.btnControleDeEstoque);
            this.Controls.Add(this.btnGerenciarProduto);
            this.Controls.Add(this.btnVoltarTelaInicial);
            this.Controls.Add(this.lblGerenciamento);
            this.Controls.Add(this.lblFundoGerenciamento);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "TelaDeGerenciamento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tela de Gerenciamento";
            this.Load += new System.EventHandler(this.TelaDeGerenciamento_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblGerenciamento;
        private System.Windows.Forms.Button btnVoltarTelaInicial;
        private System.Windows.Forms.Button btnGerenciarProduto;
        private System.Windows.Forms.Button btnControleDeEstoque;
        private System.Windows.Forms.Button btnRelatoriosDeGestao;
        private System.Windows.Forms.Label lblFundoGerenciamento;
        private System.Windows.Forms.Button btnAlertas;
        private System.Windows.Forms.Label lblAlertas1;
        private System.Windows.Forms.Label lblFundoAlertas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}