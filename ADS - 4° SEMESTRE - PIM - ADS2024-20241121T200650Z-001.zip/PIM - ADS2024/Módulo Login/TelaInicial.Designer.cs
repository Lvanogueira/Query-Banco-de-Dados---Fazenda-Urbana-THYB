﻿namespace PIM_DESKTOP_TESTE01
{
    partial class TelaInicial
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSistemaDigital = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.lblFundoLogin = new System.Windows.Forms.Label();
            this.btnLogar = new System.Windows.Forms.Button();
            this.lblFazendaUrbana = new System.Windows.Forms.Label();
            this.chkMostrarSenha = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblSistemaDigital
            // 
            this.lblSistemaDigital.AutoSize = true;
            this.lblSistemaDigital.Font = new System.Drawing.Font("Sylfaen", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSistemaDigital.Location = new System.Drawing.Point(911, 406);
            this.lblSistemaDigital.Name = "lblSistemaDigital";
            this.lblSistemaDigital.Size = new System.Drawing.Size(285, 52);
            this.lblSistemaDigital.TabIndex = 1;
            this.lblSistemaDigital.Text = "Sistema Digital";
            this.lblSistemaDigital.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSistemaDigital.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtLogin
            // 
            this.txtLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogin.Location = new System.Drawing.Point(899, 500);
            this.txtLogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(270, 38);
            this.txtLogin.TabIndex = 2;
            this.txtLogin.TextChanged += new System.EventHandler(this.txtLogin_TextChanged);
            // 
            // txtSenha
            // 
            this.txtSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSenha.Location = new System.Drawing.Point(899, 585);
            this.txtSenha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '*';
            this.txtSenha.Size = new System.Drawing.Size(270, 38);
            this.txtSenha.TabIndex = 3;
            this.txtSenha.TextChanged += new System.EventHandler(this.txtSenha_TextChanged);
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.BackColor = System.Drawing.Color.SeaGreen;
            this.lblLogin.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.Location = new System.Drawing.Point(784, 504);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(96, 35);
            this.lblLogin.TabIndex = 4;
            this.lblLogin.Text = "Login:";
            this.lblLogin.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.BackColor = System.Drawing.Color.SeaGreen;
            this.lblSenha.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenha.Location = new System.Drawing.Point(777, 589);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(103, 35);
            this.lblSenha.TabIndex = 5;
            this.lblSenha.Text = "Senha:";
            this.lblSenha.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // lblFundoLogin
            // 
            this.lblFundoLogin.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundoLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoLogin.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblFundoLogin.Location = new System.Drawing.Point(749, 470);
            this.lblFundoLogin.Name = "lblFundoLogin";
            this.lblFundoLogin.Size = new System.Drawing.Size(576, 182);
            this.lblFundoLogin.TabIndex = 6;
            this.lblFundoLogin.Text = "aaaaaaaaaaaaaaaaaaaaaaaaaa";
            // 
            // btnLogar
            // 
            this.btnLogar.BackColor = System.Drawing.Color.Black;
            this.btnLogar.Font = new System.Drawing.Font("Sylfaen", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogar.ForeColor = System.Drawing.Color.White;
            this.btnLogar.Location = new System.Drawing.Point(920, 669);
            this.btnLogar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogar.Name = "btnLogar";
            this.btnLogar.Size = new System.Drawing.Size(235, 73);
            this.btnLogar.TabIndex = 7;
            this.btnLogar.Text = "Entrar";
            this.btnLogar.UseVisualStyleBackColor = false;
            this.btnLogar.Click += new System.EventHandler(this.btnLogar_Click);
            // 
            // lblFazendaUrbana
            // 
            this.lblFazendaUrbana.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblFazendaUrbana.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFazendaUrbana.ForeColor = System.Drawing.Color.White;
            this.lblFazendaUrbana.Location = new System.Drawing.Point(660, 327);
            this.lblFazendaUrbana.Name = "lblFazendaUrbana";
            this.lblFazendaUrbana.Size = new System.Drawing.Size(763, 91);
            this.lblFazendaUrbana.TabIndex = 0;
            this.lblFazendaUrbana.Text = "Fazenda Urbana";
            this.lblFazendaUrbana.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFazendaUrbana.Click += new System.EventHandler(this.label1_Click);
            // 
            // chkMostrarSenha
            // 
            this.chkMostrarSenha.BackColor = System.Drawing.Color.SeaGreen;
            this.chkMostrarSenha.Location = new System.Drawing.Point(1184, 589);
            this.chkMostrarSenha.Name = "chkMostrarSenha";
            this.chkMostrarSenha.Size = new System.Drawing.Size(132, 23);
            this.chkMostrarSenha.TabIndex = 8;
            this.chkMostrarSenha.Text = "Mostrar Senha";
            this.chkMostrarSenha.UseVisualStyleBackColor = false;
            this.chkMostrarSenha.CheckedChanged += new System.EventHandler(this.chkMostrarSenha_CheckedChanged);
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1695, 823);
            this.Controls.Add(this.chkMostrarSenha);
            this.Controls.Add(this.btnLogar);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.lblFundoLogin);
            this.Controls.Add(this.lblSistemaDigital);
            this.Controls.Add(this.lblFazendaUrbana);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "TelaInicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tela Inicial";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblSistemaDigital;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.Label lblFundoLogin;
        private System.Windows.Forms.Button btnLogar;
        private System.Windows.Forms.Label lblFazendaUrbana;
        private System.Windows.Forms.CheckBox chkMostrarSenha;
    }
}

