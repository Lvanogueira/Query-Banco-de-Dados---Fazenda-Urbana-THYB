﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace PIM_DESKTOP_TESTE01
{
    public partial class TelaInicial : Form
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader reader;
        public TelaInicial()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void btnLogar_Click(object sender, EventArgs e)
        {

            // Captura as entradas de login e senha
            string login = txtLogin.Text;
            string senha = txtSenha.Text;

            // String de conexão (substitua os valores pelo nome do seu servidor, banco de dados, etc.)
            string connectionString = @"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;";
            // Query SQL para verificar as credenciais
            string query = "SELECT COUNT(1) FROM PerfilAdmin WHERE Email = @Email AND Senha = @Senha";

            // Conexão com o banco de dados
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open(); // Abre a conexão com o banco

                    // Cria o comando SQL
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        // Adiciona os parâmetros para evitar SQL Injection
                        cmd.Parameters.AddWithValue("@Email", login);
                        cmd.Parameters.AddWithValue("@Senha", senha);

                        // Executa o comando e verifica se a combinação de email e senha existe
                        int count = Convert.ToInt32(cmd.ExecuteScalar());

                        if (count == 1)
                        /* A variável count no código representa o número de linhas que correspondem à consulta SQL, ou seja, o número de registros no banco de dados que satisfazem a combinação de email e senha./*

                        Nessa parte o codigo está executando uma consulta que conta quantos registros existem na tabela PerfilAdmin onde o email e a senha correspondem aos valores inseridos pelo usuário.

                        COUNT(1): Conta quantas linhas a consulta retorna. Nesse caso, a consulta retorna 1 ou 0.
                        Se a combinação de email e senha for encontrada, o resultado será 1.
                        Se não houver nenhuma correspondência, o resultado será 0.

                        Verificação:

                       Se count == 1, significa que a combinação de email e senha foi encontrada no banco de dados, e o login é bem - sucedido.
                       Se count == 0, significa que a combinação de email e senha não foi encontrada, e o login falhou.*/
                        {
                            MessageBox.Show("Login bem-sucedido!");

                            TelaInicial telaInicial = new TelaInicial();
                            telaInicial.WindowState = FormWindowState.Maximized;
                            telaInicial.FormBorderStyle = FormBorderStyle.None;

                            TelaDeGerenciamento telaDeGerenciamento = new TelaDeGerenciamento();
                            telaDeGerenciamento.WindowState = FormWindowState.Maximized;
                            telaDeGerenciamento.FormBorderStyle = FormBorderStyle.None;

                            this.Hide(); // Esconde o formulário atual (Form1)
                            telaDeGerenciamento.Show();

                            // Ao fechar o próximo formulário, exibe novamente o formulário atual
                            this.FormClosed += (s, args) => telaDeGerenciamento.Show();

                        }
                        else
                        {
                            MessageBox.Show("Usuário ou senha incorretos. Tente novamente.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                }
            }
        }

        private void chkMostrarSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMostrarSenha.Checked)
            {
                txtSenha.PasswordChar = '\0'; // Exibe a senha
            }
            else
            {
                txtSenha.PasswordChar = '*'; // Oculta a senha novamente
            }
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLogin_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
