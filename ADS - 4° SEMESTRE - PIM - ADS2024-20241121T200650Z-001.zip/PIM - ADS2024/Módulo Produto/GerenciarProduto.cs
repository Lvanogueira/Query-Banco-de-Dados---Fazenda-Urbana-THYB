﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.OleDb;

namespace PIM_DESKTOP_TESTE01
{
    public partial class GerenciarProduto : Form
    {
        public GerenciarProduto()
        {
            InitializeComponent();
        }

        SqlConnection cn = new SqlConnection(@"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;");
        SqlCommand cm = new SqlCommand(); //Comando para enviar instruções para o Banco de Dados 
        SqlDataReader dt; //Comando usado para receber dados de um select no Banco de Dados. (Leitor de Dados)

        private void GerenciarProduto_Load(object sender, EventArgs e)
        {
            CarregarProdutos(); // Carrega todos os produtos no DataGridView
            dataGridView1.SelectionChanged += new EventHandler(dataGridView1_SelectionChanged);
        }

        private void btnVoltarGerenciamento_Click(object sender, EventArgs e)
        {
            TelaDeGerenciamento telaDeGerenciamento = new TelaDeGerenciamento();
            telaDeGerenciamento.WindowState = FormWindowState.Maximized;
            telaDeGerenciamento.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            telaDeGerenciamento.Show();

            this.FormClosed += (s, args) => telaDeGerenciamento.Show();

        }

        private void lblFotoProduto_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private void lblDescriçãodoProduto_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                string strSQL = "insert into CadastroDeProdutos(Nome,PrecoProduto,QuantidadeDeProdutos,DescricaoProduto)values(@Nome,@PrecoProduto,@QuantidadeDeProdutos,@DescricaoProduto)";
                {
                    cm.Parameters.Clear(); // Limpa os parâmetros antes de adicionar
                    cm.Parameters.Add("@Nome", SqlDbType.VarChar).Value = txtNomeProduto.Text;
                    cm.Parameters.Add("@PrecoProduto", SqlDbType.Decimal).Value = mskPrecoProduto.Text;
                    cm.Parameters.Add("@QuantidadeDeProdutos", SqlDbType.Int).Value = mskQuantidadeDeProdutos.Text;
                    cm.Parameters.Add("@DescricaoProduto", SqlDbType.VarChar).Value = txtDescricaoProduto.Text;

                    cm.Connection = cn; // Comando insert sera usado nessa conexão
                    cm.CommandText = strSQL; // vai enviar os comando de texto da string para o Banco de Dados

                    cm.ExecuteNonQuery(); // Comando para executar, vai executar o comando de texto da string - inserto into
                    MessageBox.Show("Produto Cadastrado com Sucesso !!", "Produtos Cadastrados", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    cn.Close(); // Fechando 

                    CarregarProdutos();
                    LimparCampos();

                }
            }
            catch (Exception erro)
            {
                // try catch se caso nao for executado o processo ele vai explodi uma menssagem de erro na tela.
                MessageBox.Show(erro.Message); // Informa qual o erro ocorreu
                cn.Close();
            }


        }
        private void txtPrecoProduto_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblFundo_Click(object sender, EventArgs e)
        {

        }

        private void txtDescricaoProduto_TextChanged(object sender, EventArgs e)
        {

        }

        private void mskQuantidadeDeProdutos_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblQuantidadeItens_Click(object sender, EventArgs e)
        {

        }

        private void lblPrecoProduto_Click(object sender, EventArgs e)
        {

        }

        private void txtNomeProduto_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblNomeProduto_Click(object sender, EventArgs e)
        {

        }

        private void lblGerenciarProduto_Click(object sender, EventArgs e)
        {

        }

        private void lblAlterarProduto_Click(object sender, EventArgs e)
        {

        }

        private void txtNomeProduto2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPrecoProduto2_Click(object sender, EventArgs e)
        {

        }

        private void mskPrecoProduto2_TextChanged(object sender, EventArgs e)
        {

        }

        private void mskQuantidadeDeProdutos2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblQuantidadeItens2_Click(object sender, EventArgs e)
        {

        }
        private void txtDescricaoProduto3_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                string strSQL = "UPDATE CadastroDeProdutos SET Nome = @Nome, PrecoProduto = @PrecoProduto, QuantidadeDeProdutos = @QuantidadeDeProdutos, DescricaoProduto = @DescricaoProduto WHERE IdProduto = @IdProduto";

                cm.Parameters.Clear(); // Limpa os parâmetros antes de adicionar

                // Adiciona apenas os campos que foram alterados
                if (!string.IsNullOrWhiteSpace(txtNomeProduto2.Text))
                {
                    cm.Parameters.Add("@Nome", SqlDbType.VarChar).Value = txtNomeProduto2.Text;
                }
                if (!string.IsNullOrWhiteSpace(mskPrecoProduto2.Text) && Decimal.TryParse(mskPrecoProduto2.Text, out decimal preco))
                {
                    cm.Parameters.Add("@PrecoProduto", SqlDbType.Decimal).Value = preco;
                }
                if (!string.IsNullOrWhiteSpace(mskQuantidadeDeProdutos2.Text) && Int32.TryParse(mskQuantidadeDeProdutos2.Text, out int quantidade))
                {
                    cm.Parameters.Add("@QuantidadeDeProdutos", SqlDbType.Int).Value = quantidade;
                }
                if (!string.IsNullOrWhiteSpace(txtDescricaoProduto2.Text))
                {
                    cm.Parameters.Add("@DescricaoProduto", SqlDbType.VarChar).Value = txtDescricaoProduto2.Text;
                }

                // Certifique-se de que o ID do produto está sempre preenchido
                cm.Parameters.Add("@IdProduto", SqlDbType.Int).Value = Convert.ToInt32(txtIdProduto2.Text);

                cm.Connection = cn; // Comando update sera usado nessa conexão
                cm.CommandText = strSQL; // vai enviar os comando de texto da string para o Banco de Dados

                cm.ExecuteNonQuery(); // Comando para executar, vai executar o comando de texto da string - update
                MessageBox.Show("Produto Alterado com Sucesso !!", "Produtos Alterado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                cn.Close(); // Fechando conexão com banco
                CarregarProdutos();
                LimparCampos();
            }
            catch (Exception erro)
            {
                // try catch se caso nao for executado o processo ele vai explodi uma menssagem de erro na tela.
                MessageBox.Show(erro.Message); // Informa qual o erro ocorreu
                cn.Close();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                string strSQL = "DELETE FROM CadastroDeProdutos WHERE IdProduto = @IdProduto";

                cm.Parameters.Clear();
                cm.Parameters.Add("@IdProduto", SqlDbType.Int).Value = Convert.ToInt32(txtIdProduto2.Text); // Garantindo que o valor é um inteiro

                cm.Connection = cn;
                cm.CommandText = strSQL;

                cm.ExecuteNonQuery();
                MessageBox.Show("Produto Excluído com Sucesso!");
                
                cn.Close();

                // Atualizar DataGridView com os novos dados
                CarregarProdutos();
                //limpa os campos
                LimparCampos();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
                cn.Close();
            }
        }
        private void CarregarProdutos()
        {
            try
            {
                cn.Open();
                string strSQL = "SELECT IdProduto, Nome, PrecoProduto, QuantidadeDeProdutos, DescricaoProduto FROM CadastroDeProdutos";
                SqlDataAdapter da = new SqlDataAdapter(strSQL, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Exibir os dados no DataGridView
                dataGridView1.DataSource = dt;

                cn.Close();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
                cn.Close();
            }
        }
        private void LimparCampos()
        {
            txtNomeProduto.Text = "";
            mskPrecoProduto.Text = "";
            mskQuantidadeDeProdutos.Text = "";
            txtDescricaoProduto.Text = "";
            txtIdProduto2.Text = ""; // Para limpar o ID do produto após alteração
            txtNomeProduto2.Text = "";
            mskPrecoProduto2.Text = "";
            mskQuantidadeDeProdutos2.Text = "";
            txtDescricaoProduto2.Text = "";
        }
        private void dataGridViewProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica se há uma linha válida selecionada
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Preenche os campos de texto com os dados da linha selecionada
                txtIdProduto2.Text = row.Cells["IdProduto"].Value.ToString();
                txtNomeProduto2.Text = row.Cells["Nome"].Value.ToString();
                mskPrecoProduto2.Text = row.Cells["PrecoProduto"].Value.ToString();
                mskQuantidadeDeProdutos2.Text = row.Cells["QuantidadeDeProdutos"].Value.ToString();
                txtDescricaoProduto2.Text = row.Cells["DescricaoProduto"].Value.ToString();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0) // Verifica se há alguma linha selecionada
            {
                // Pega a linha selecionada
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // Preenche os campos com os valores da linha selecionada
                txtIdProduto2.Text = row.Cells["IdProduto"].Value.ToString();
                txtNomeProduto2.Text = row.Cells["Nome"].Value.ToString();
                mskPrecoProduto2.Text = row.Cells["PrecoProduto"].Value.ToString();
                mskQuantidadeDeProdutos2.Text = row.Cells["QuantidadeDeProdutos"].Value.ToString();
                txtDescricaoProduto2.Text = row.Cells["DescricaoProduto"].Value.ToString();
            }
        }

        private void lblIdProduto_Click(object sender, EventArgs e)
        {

        }

        private void lblIdProduto2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
