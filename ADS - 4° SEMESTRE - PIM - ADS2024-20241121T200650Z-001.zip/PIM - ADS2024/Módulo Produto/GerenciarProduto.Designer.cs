﻿namespace PIM_DESKTOP_TESTE01
{
    partial class GerenciarProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGerenciarProduto = new System.Windows.Forms.Label();
            this.lblNomeProduto = new System.Windows.Forms.Label();
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.lblPrecoProduto = new System.Windows.Forms.Label();
            this.mskPrecoProduto = new System.Windows.Forms.TextBox();
            this.lblQuantidadeItens = new System.Windows.Forms.Label();
            this.mskQuantidadeDeProdutos = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.lblFundoGerenciamento = new System.Windows.Forms.Label();
            this.lblDescriçãodoProduto = new System.Windows.Forms.Label();
            this.txtDescricaoProduto = new System.Windows.Forms.TextBox();
            this.lblFundo = new System.Windows.Forms.Label();
            this.lblDivisao1 = new System.Windows.Forms.Label();
            this.lblAlterarProduto = new System.Windows.Forms.Label();
            this.lblDivisao2 = new System.Windows.Forms.Label();
            this.lblNomeProduto2 = new System.Windows.Forms.Label();
            this.lblPrecoProduto2 = new System.Windows.Forms.Label();
            this.mskPrecoProduto2 = new System.Windows.Forms.TextBox();
            this.lblQuantidadeItens2 = new System.Windows.Forms.Label();
            this.mskQuantidadeDeProdutos2 = new System.Windows.Forms.TextBox();
            this.lblDescriçãodoProduto2 = new System.Windows.Forms.Label();
            this.txtDescricaoProduto2 = new System.Windows.Forms.TextBox();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.lblExcluirProduto = new System.Windows.Forms.Label();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblIdProduto = new System.Windows.Forms.Label();
            this.txtNomeProduto2 = new System.Windows.Forms.TextBox();
            this.lblIdProduto2 = new System.Windows.Forms.Label();
            this.txtIdProduto2 = new System.Windows.Forms.TextBox();
            this.btnVoltarGerenciamento = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblGerenciarProduto
            // 
            this.lblGerenciarProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblGerenciarProduto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGerenciarProduto.Font = new System.Drawing.Font("Lucida Sans", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGerenciarProduto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblGerenciarProduto.Location = new System.Drawing.Point(501, 239);
            this.lblGerenciarProduto.Name = "lblGerenciarProduto";
            this.lblGerenciarProduto.Size = new System.Drawing.Size(282, 101);
            this.lblGerenciarProduto.TabIndex = 1;
            this.lblGerenciarProduto.Text = "Cadastrar Produto";
            this.lblGerenciarProduto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblGerenciarProduto.Click += new System.EventHandler(this.lblGerenciarProduto_Click);
            // 
            // lblNomeProduto
            // 
            this.lblNomeProduto.AutoSize = true;
            this.lblNomeProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblNomeProduto.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProduto.Location = new System.Drawing.Point(510, 362);
            this.lblNomeProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeProduto.Name = "lblNomeProduto";
            this.lblNomeProduto.Size = new System.Drawing.Size(273, 34);
            this.lblNomeProduto.TabIndex = 1;
            this.lblNomeProduto.Text = "Nome do Produto";
            this.lblNomeProduto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNomeProduto.Click += new System.EventHandler(this.lblNomeProduto_Click);
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtNomeProduto.Location = new System.Drawing.Point(549, 400);
            this.txtNomeProduto.Margin = new System.Windows.Forms.Padding(4);
            this.txtNomeProduto.Multiline = true;
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(184, 34);
            this.txtNomeProduto.TabIndex = 2;
            this.txtNomeProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNomeProduto.TextChanged += new System.EventHandler(this.txtNomeProduto_TextChanged);
            // 
            // lblPrecoProduto
            // 
            this.lblPrecoProduto.AutoSize = true;
            this.lblPrecoProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblPrecoProduto.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblPrecoProduto.Location = new System.Drawing.Point(516, 452);
            this.lblPrecoProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrecoProduto.Name = "lblPrecoProduto";
            this.lblPrecoProduto.Size = new System.Drawing.Size(267, 34);
            this.lblPrecoProduto.TabIndex = 3;
            this.lblPrecoProduto.Text = "Preço do Produto";
            this.lblPrecoProduto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPrecoProduto.Click += new System.EventHandler(this.lblPrecoProduto_Click);
            // 
            // mskPrecoProduto
            // 
            this.mskPrecoProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.mskPrecoProduto.Location = new System.Drawing.Point(549, 490);
            this.mskPrecoProduto.Margin = new System.Windows.Forms.Padding(4);
            this.mskPrecoProduto.Multiline = true;
            this.mskPrecoProduto.Name = "mskPrecoProduto";
            this.mskPrecoProduto.Size = new System.Drawing.Size(184, 34);
            this.mskPrecoProduto.TabIndex = 4;
            this.mskPrecoProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskPrecoProduto.TextChanged += new System.EventHandler(this.txtPrecoProduto_TextChanged);
            // 
            // lblQuantidadeItens
            // 
            this.lblQuantidadeItens.BackColor = System.Drawing.Color.SeaGreen;
            this.lblQuantidadeItens.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblQuantidadeItens.Location = new System.Drawing.Point(492, 537);
            this.lblQuantidadeItens.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuantidadeItens.Name = "lblQuantidadeItens";
            this.lblQuantidadeItens.Size = new System.Drawing.Size(383, 31);
            this.lblQuantidadeItens.TabIndex = 5;
            this.lblQuantidadeItens.Text = "Quantidade de Itens";
            this.lblQuantidadeItens.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblQuantidadeItens.Click += new System.EventHandler(this.lblQuantidadeItens_Click);
            // 
            // mskQuantidadeDeProdutos
            // 
            this.mskQuantidadeDeProdutos.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.mskQuantidadeDeProdutos.Location = new System.Drawing.Point(549, 584);
            this.mskQuantidadeDeProdutos.Margin = new System.Windows.Forms.Padding(4);
            this.mskQuantidadeDeProdutos.Multiline = true;
            this.mskQuantidadeDeProdutos.Name = "mskQuantidadeDeProdutos";
            this.mskQuantidadeDeProdutos.Size = new System.Drawing.Size(184, 36);
            this.mskQuantidadeDeProdutos.TabIndex = 6;
            this.mskQuantidadeDeProdutos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskQuantidadeDeProdutos.TextChanged += new System.EventHandler(this.mskQuantidadeDeProdutos_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1054, 535);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 7;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.BackColor = System.Drawing.Color.Black;
            this.btnCadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCadastrar.Location = new System.Drawing.Point(549, 837);
            this.btnCadastrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(194, 60);
            this.btnCadastrar.TabIndex = 13;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = false;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // lblFundoGerenciamento
            // 
            this.lblFundoGerenciamento.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundoGerenciamento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFundoGerenciamento.Location = new System.Drawing.Point(583, 232);
            this.lblFundoGerenciamento.Name = "lblFundoGerenciamento";
            this.lblFundoGerenciamento.Size = new System.Drawing.Size(1042, 648);
            this.lblFundoGerenciamento.TabIndex = 15;
            // 
            // lblDescriçãodoProduto
            // 
            this.lblDescriçãodoProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblDescriçãodoProduto.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblDescriçãodoProduto.Location = new System.Drawing.Point(481, 633);
            this.lblDescriçãodoProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriçãodoProduto.Name = "lblDescriçãodoProduto";
            this.lblDescriçãodoProduto.Size = new System.Drawing.Size(356, 39);
            this.lblDescriçãodoProduto.TabIndex = 16;
            this.lblDescriçãodoProduto.Text = "Descrição do Produto";
            this.lblDescriçãodoProduto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDescriçãodoProduto.Click += new System.EventHandler(this.lblDescriçãodoProduto_Click);
            // 
            // txtDescricaoProduto
            // 
            this.txtDescricaoProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtDescricaoProduto.Location = new System.Drawing.Point(531, 687);
            this.txtDescricaoProduto.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescricaoProduto.Multiline = true;
            this.txtDescricaoProduto.Name = "txtDescricaoProduto";
            this.txtDescricaoProduto.Size = new System.Drawing.Size(225, 117);
            this.txtDescricaoProduto.TabIndex = 17;
            this.txtDescricaoProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDescricaoProduto.TextChanged += new System.EventHandler(this.txtDescricaoProduto_TextChanged);
            // 
            // lblFundo
            // 
            this.lblFundo.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFundo.Location = new System.Drawing.Point(444, 209);
            this.lblFundo.Name = "lblFundo";
            this.lblFundo.Size = new System.Drawing.Size(1196, 742);
            this.lblFundo.TabIndex = 15;
            this.lblFundo.Click += new System.EventHandler(this.lblFundo_Click);
            // 
            // lblDivisao1
            // 
            this.lblDivisao1.BackColor = System.Drawing.Color.LightGreen;
            this.lblDivisao1.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblDivisao1.Location = new System.Drawing.Point(844, 239);
            this.lblDivisao1.Name = "lblDivisao1";
            this.lblDivisao1.Size = new System.Drawing.Size(10, 658);
            this.lblDivisao1.TabIndex = 18;
            this.lblDivisao1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblAlterarProduto
            // 
            this.lblAlterarProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblAlterarProduto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAlterarProduto.Font = new System.Drawing.Font("Lucida Sans", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlterarProduto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAlterarProduto.Location = new System.Drawing.Point(1307, 231);
            this.lblAlterarProduto.Name = "lblAlterarProduto";
            this.lblAlterarProduto.Size = new System.Drawing.Size(276, 92);
            this.lblAlterarProduto.TabIndex = 19;
            this.lblAlterarProduto.Text = "Alterar Produto";
            this.lblAlterarProduto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAlterarProduto.Click += new System.EventHandler(this.lblAlterarProduto_Click);
            // 
            // lblDivisao2
            // 
            this.lblDivisao2.BackColor = System.Drawing.Color.LightGreen;
            this.lblDivisao2.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblDivisao2.Location = new System.Drawing.Point(1243, 239);
            this.lblDivisao2.Name = "lblDivisao2";
            this.lblDivisao2.Size = new System.Drawing.Size(10, 658);
            this.lblDivisao2.TabIndex = 20;
            this.lblDivisao2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblNomeProduto2
            // 
            this.lblNomeProduto2.AutoSize = true;
            this.lblNomeProduto2.BackColor = System.Drawing.Color.SeaGreen;
            this.lblNomeProduto2.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProduto2.Location = new System.Drawing.Point(1319, 467);
            this.lblNomeProduto2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeProduto2.Name = "lblNomeProduto2";
            this.lblNomeProduto2.Size = new System.Drawing.Size(273, 34);
            this.lblNomeProduto2.TabIndex = 21;
            this.lblNomeProduto2.Text = "Nome do Produto";
            this.lblNomeProduto2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNomeProduto2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblPrecoProduto2
            // 
            this.lblPrecoProduto2.AutoSize = true;
            this.lblPrecoProduto2.BackColor = System.Drawing.Color.SeaGreen;
            this.lblPrecoProduto2.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblPrecoProduto2.Location = new System.Drawing.Point(1312, 548);
            this.lblPrecoProduto2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrecoProduto2.Name = "lblPrecoProduto2";
            this.lblPrecoProduto2.Size = new System.Drawing.Size(267, 34);
            this.lblPrecoProduto2.TabIndex = 23;
            this.lblPrecoProduto2.Text = "Preço do Produto";
            this.lblPrecoProduto2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPrecoProduto2.Click += new System.EventHandler(this.lblPrecoProduto2_Click);
            // 
            // mskPrecoProduto2
            // 
            this.mskPrecoProduto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.mskPrecoProduto2.Location = new System.Drawing.Point(1350, 586);
            this.mskPrecoProduto2.Margin = new System.Windows.Forms.Padding(4);
            this.mskPrecoProduto2.Multiline = true;
            this.mskPrecoProduto2.Name = "mskPrecoProduto2";
            this.mskPrecoProduto2.Size = new System.Drawing.Size(184, 34);
            this.mskPrecoProduto2.TabIndex = 24;
            this.mskPrecoProduto2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskPrecoProduto2.TextChanged += new System.EventHandler(this.mskPrecoProduto2_TextChanged);
            // 
            // lblQuantidadeItens2
            // 
            this.lblQuantidadeItens2.BackColor = System.Drawing.Color.SeaGreen;
            this.lblQuantidadeItens2.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblQuantidadeItens2.Location = new System.Drawing.Point(1265, 624);
            this.lblQuantidadeItens2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuantidadeItens2.Name = "lblQuantidadeItens2";
            this.lblQuantidadeItens2.Size = new System.Drawing.Size(354, 31);
            this.lblQuantidadeItens2.TabIndex = 25;
            this.lblQuantidadeItens2.Text = "Quantidade de Itens";
            this.lblQuantidadeItens2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQuantidadeItens2.Click += new System.EventHandler(this.lblQuantidadeItens2_Click);
            // 
            // mskQuantidadeDeProdutos2
            // 
            this.mskQuantidadeDeProdutos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.mskQuantidadeDeProdutos2.Location = new System.Drawing.Point(1350, 668);
            this.mskQuantidadeDeProdutos2.Margin = new System.Windows.Forms.Padding(4);
            this.mskQuantidadeDeProdutos2.Multiline = true;
            this.mskQuantidadeDeProdutos2.Name = "mskQuantidadeDeProdutos2";
            this.mskQuantidadeDeProdutos2.Size = new System.Drawing.Size(184, 36);
            this.mskQuantidadeDeProdutos2.TabIndex = 26;
            this.mskQuantidadeDeProdutos2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskQuantidadeDeProdutos2.TextChanged += new System.EventHandler(this.mskQuantidadeDeProdutos2_TextChanged);
            // 
            // lblDescriçãodoProduto2
            // 
            this.lblDescriçãodoProduto2.BackColor = System.Drawing.Color.SeaGreen;
            this.lblDescriçãodoProduto2.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblDescriçãodoProduto2.Location = new System.Drawing.Point(1265, 715);
            this.lblDescriçãodoProduto2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriçãodoProduto2.Name = "lblDescriçãodoProduto2";
            this.lblDescriçãodoProduto2.Size = new System.Drawing.Size(354, 39);
            this.lblDescriçãodoProduto2.TabIndex = 27;
            this.lblDescriçãodoProduto2.Text = "Descrição do Produto";
            this.lblDescriçãodoProduto2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDescricaoProduto2
            // 
            this.txtDescricaoProduto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtDescricaoProduto2.Location = new System.Drawing.Point(1332, 758);
            this.txtDescricaoProduto2.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescricaoProduto2.Multiline = true;
            this.txtDescricaoProduto2.Name = "txtDescricaoProduto2";
            this.txtDescricaoProduto2.Size = new System.Drawing.Size(225, 73);
            this.txtDescricaoProduto2.TabIndex = 28;
            this.txtDescricaoProduto2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAlterar
            // 
            this.btnAlterar.BackColor = System.Drawing.Color.Black;
            this.btnAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAlterar.Location = new System.Drawing.Point(1350, 839);
            this.btnAlterar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(194, 60);
            this.btnAlterar.TabIndex = 29;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.UseVisualStyleBackColor = false;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // lblExcluirProduto
            // 
            this.lblExcluirProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblExcluirProduto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblExcluirProduto.Font = new System.Drawing.Font("Lucida Sans", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExcluirProduto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblExcluirProduto.Location = new System.Drawing.Point(911, 248);
            this.lblExcluirProduto.Name = "lblExcluirProduto";
            this.lblExcluirProduto.Size = new System.Drawing.Size(282, 92);
            this.lblExcluirProduto.TabIndex = 30;
            this.lblExcluirProduto.Text = "Excluir Produto";
            this.lblExcluirProduto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.Black;
            this.btnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExcluir.Location = new System.Drawing.Point(948, 464);
            this.btnExcluir.Margin = new System.Windows.Forms.Padding(4);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(194, 60);
            this.btnExcluir.TabIndex = 39;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1273, 369);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(346, 91);
            this.dataGridView1.TabIndex = 40;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblIdProduto
            // 
            this.lblIdProduto.AutoSize = true;
            this.lblIdProduto.BackColor = System.Drawing.Color.SeaGreen;
            this.lblIdProduto.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblIdProduto.Location = new System.Drawing.Point(942, 369);
            this.lblIdProduto.Name = "lblIdProduto";
            this.lblIdProduto.Size = new System.Drawing.Size(218, 34);
            this.lblIdProduto.TabIndex = 41;
            this.lblIdProduto.Text = "ID do Produto";
            this.lblIdProduto.Click += new System.EventHandler(this.lblIdProduto_Click);
            // 
            // txtNomeProduto2
            // 
            this.txtNomeProduto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeProduto2.Location = new System.Drawing.Point(1341, 504);
            this.txtNomeProduto2.Multiline = true;
            this.txtNomeProduto2.Name = "txtNomeProduto2";
            this.txtNomeProduto2.Size = new System.Drawing.Size(184, 31);
            this.txtNomeProduto2.TabIndex = 42;
            // 
            // lblIdProduto2
            // 
            this.lblIdProduto2.AutoSize = true;
            this.lblIdProduto2.BackColor = System.Drawing.Color.SeaGreen;
            this.lblIdProduto2.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblIdProduto2.Location = new System.Drawing.Point(1335, 332);
            this.lblIdProduto2.Name = "lblIdProduto2";
            this.lblIdProduto2.Size = new System.Drawing.Size(218, 34);
            this.lblIdProduto2.TabIndex = 43;
            this.lblIdProduto2.Text = "ID do Produto";
            this.lblIdProduto2.Click += new System.EventHandler(this.lblIdProduto2_Click);
            // 
            // txtIdProduto2
            // 
            this.txtIdProduto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtIdProduto2.Location = new System.Drawing.Point(948, 412);
            this.txtIdProduto2.Multiline = true;
            this.txtIdProduto2.Name = "txtIdProduto2";
            this.txtIdProduto2.Size = new System.Drawing.Size(194, 45);
            this.txtIdProduto2.TabIndex = 44;
            // 
            // btnVoltarGerenciamento
            // 
            this.btnVoltarGerenciamento.BackColor = System.Drawing.Color.SeaGreen;
            this.btnVoltarGerenciamento.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.home_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnVoltarGerenciamento.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnVoltarGerenciamento.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnVoltarGerenciamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))));
            this.btnVoltarGerenciamento.ForeColor = System.Drawing.Color.White;
            this.btnVoltarGerenciamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVoltarGerenciamento.ImageKey = "(nenhum/a)";
            this.btnVoltarGerenciamento.Location = new System.Drawing.Point(0, 63);
            this.btnVoltarGerenciamento.Name = "btnVoltarGerenciamento";
            this.btnVoltarGerenciamento.Size = new System.Drawing.Size(482, 75);
            this.btnVoltarGerenciamento.TabIndex = 14;
            this.btnVoltarGerenciamento.Text = "Voltar para Gerenciamento\r\n";
            this.btnVoltarGerenciamento.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVoltarGerenciamento.UseVisualStyleBackColor = false;
            this.btnVoltarGerenciamento.Click += new System.EventHandler(this.btnVoltarGerenciamento_Click);
            // 
            // GerenciarProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1924, 944);
            this.Controls.Add(this.txtIdProduto2);
            this.Controls.Add(this.lblIdProduto2);
            this.Controls.Add(this.txtNomeProduto2);
            this.Controls.Add(this.lblIdProduto);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.lblExcluirProduto);
            this.Controls.Add(this.btnAlterar);
            this.Controls.Add(this.txtDescricaoProduto2);
            this.Controls.Add(this.lblDescriçãodoProduto2);
            this.Controls.Add(this.mskQuantidadeDeProdutos2);
            this.Controls.Add(this.lblQuantidadeItens2);
            this.Controls.Add(this.mskPrecoProduto2);
            this.Controls.Add(this.lblPrecoProduto2);
            this.Controls.Add(this.lblNomeProduto2);
            this.Controls.Add(this.lblDivisao2);
            this.Controls.Add(this.lblAlterarProduto);
            this.Controls.Add(this.lblDivisao1);
            this.Controls.Add(this.txtDescricaoProduto);
            this.Controls.Add(this.lblDescriçãodoProduto);
            this.Controls.Add(this.btnVoltarGerenciamento);
            this.Controls.Add(this.btnCadastrar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mskQuantidadeDeProdutos);
            this.Controls.Add(this.lblQuantidadeItens);
            this.Controls.Add(this.mskPrecoProduto);
            this.Controls.Add(this.lblPrecoProduto);
            this.Controls.Add(this.txtNomeProduto);
            this.Controls.Add(this.lblNomeProduto);
            this.Controls.Add(this.lblGerenciarProduto);
            this.Controls.Add(this.lblFundo);
            this.Controls.Add(this.lblFundoGerenciamento);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "GerenciarProduto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Cadastrar Produto";
            this.Load += new System.EventHandler(this.GerenciarProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblGerenciarProduto;
        public System.Windows.Forms.Label lblNomeProduto;
        public System.Windows.Forms.TextBox txtNomeProduto;
        public System.Windows.Forms.Label lblPrecoProduto;
        public System.Windows.Forms.TextBox mskPrecoProduto;
        public System.Windows.Forms.Label lblQuantidadeItens;
        public System.Windows.Forms.TextBox mskQuantidadeDeProdutos;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Label lblFundoGerenciamento;
        public System.Windows.Forms.Label lblDescriçãodoProduto;
        public System.Windows.Forms.TextBox txtDescricaoProduto;
        private System.Windows.Forms.Button btnVoltarGerenciamento;
        private System.Windows.Forms.Label lblFundo;
        private System.Windows.Forms.Label lblDivisao1;
        public System.Windows.Forms.Label lblAlterarProduto;
        private System.Windows.Forms.Label lblDivisao2;
        public System.Windows.Forms.Label lblNomeProduto2;
        public System.Windows.Forms.Label lblPrecoProduto2;
        public System.Windows.Forms.TextBox mskPrecoProduto2;
        public System.Windows.Forms.Label lblQuantidadeItens2;
        public System.Windows.Forms.TextBox mskQuantidadeDeProdutos2;
        public System.Windows.Forms.Label lblDescriçãodoProduto2;
        public System.Windows.Forms.TextBox txtDescricaoProduto2;
        public System.Windows.Forms.Button btnAlterar;
        public System.Windows.Forms.Label lblExcluirProduto;
        public System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblIdProduto;
        public System.Windows.Forms.TextBox txtNomeProduto2;
        private System.Windows.Forms.Label lblIdProduto2;
        private System.Windows.Forms.TextBox txtIdProduto2;
    }
}