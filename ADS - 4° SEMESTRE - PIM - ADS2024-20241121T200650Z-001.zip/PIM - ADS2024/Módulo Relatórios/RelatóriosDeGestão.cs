﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace PIM_DESKTOP_TESTE01
{
    public partial class RelatóriosDeGestão : Form
    {
        public RelatóriosDeGestão()
        {
            InitializeComponent();
        }

        private void RelatóriosDeGestão_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;";

            // Atualizar ambos os gráficos na inicialização do formulário
            AtualizarGraficoPizza(connectionString);
            AtualizarGraficoColuna(connectionString);

            // Atualizar o gráfico de vendas mensais
            AtualizarGraficoVendasMensais();

            timer1.Start();
        }

        private void AtualizarGraficoPizza(string connectionString)
        {
            string query = "SELECT Nome, QuantidadeDeProdutos FROM CadastroDeProdutos";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                chart1.Series.Clear();
                Series series = chart1.Series.Add("Quantidade de produtos no Estoque");
                series.ChartType = SeriesChartType.Pie;
                series.IsValueShownAsLabel = true; // Exibir valores nos segmentos

                foreach (DataRow row in dt.Rows)
                {
                    series.Points.AddXY(row["Nome"].ToString(), row["QuantidadeDeProdutos"]);
                }
            }
        }

        private void AtualizarGraficoColuna(string connectionString)
        {
            string query = "SELECT Nome, QuantidadeMaterial FROM Fornecedores";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                chart2.Series.Clear();
                Series series = chart2.Series.Add("Quantidade de Matérias-Primas para Produção");
                series.ChartType = SeriesChartType.Column;
                series.IsValueShownAsLabel = true; // Exibir valores acima das colunas

                foreach (DataRow row in dt.Rows)
                {
                    series.Points.AddXY(row["Nome"].ToString(), row["QuantidadeMaterial"]);
                }
            }
        }

        private void AtualizarGraficoVendasMensais()
        {
            // Limpa as séries antigas
            chart3.Series.Clear();
            chart3.Legends.Clear();
            chart3.ChartAreas.Clear();

            // Configura o gráfico com uma área de gráfico
            chart3.ChartAreas.Add(new ChartArea());

            // Cria uma nova série de dados para o valor total da compra
            Series serieCompra = chart3.Series.Add("Valor Total da Compra");
            serieCompra.ChartType = SeriesChartType.Column;
            serieCompra.IsValueShownAsLabel = true;
            serieCompra.Label = "R$ 20,50\nData: 27/11/2024"; // Exibe o valor total da compra e a data no gráfico

            // Dados da compra
            string cliente = "Cristiane";
            int quantidadeAlface = 2;
            int quantidadeCenoura = 3;
            int quantidadeTomate = 1;
            decimal precoAlface = 3.50m;
            decimal precoCenoura = 3.00m;
            decimal precoTomate = 4.50m;
            decimal totalVenda = (quantidadeAlface * precoAlface) +
                                 (quantidadeCenoura * precoCenoura) +
                                 (quantidadeTomate * precoTomate);

            // Adiciona o valor total da compra ao gráfico
            DataPoint pontoCompra = new DataPoint();
            pontoCompra.SetValueXY(cliente, totalVenda);
            pontoCompra.ToolTip = $"Cliente: {cliente}\nValor Total: R$ {totalVenda}\nData: 27/11/2024";
            serieCompra.Points.Add(pontoCompra);

            // Adiciona legenda ao lado com os detalhes dos produtos vendidos, sem a data
            Legend legenda = new Legend("Detalhes da Compra");
            chart3.Legends.Add(legenda);

            legenda.Docking = Docking.Right;
            legenda.Title = "Produtos Vendidos"; // Remove a data do título da legenda
            legenda.BackColor = Color.LightGray;

            // Adiciona os produtos vendidos na legenda
            legenda.CustomItems.Add(Color.Green, $"2 Alfaces - R$ {quantidadeAlface * precoAlface}");
            legenda.CustomItems.Add(Color.Orange, $"3 Cenouras - R$ {quantidadeCenoura * precoCenoura}");
            legenda.CustomItems.Add(Color.Red, $"1 Tomate - R$ {quantidadeTomate * precoTomate}");

            // Configurações finais do gráfico
            chart3.Titles.Clear();
            chart3.Titles.Add("Vendas Mensais");
            chart3.ChartAreas[0].AxisX.Title = "Cliente";
            chart3.ChartAreas[0].AxisY.Title = "Valor Total (R$)";
            chart3.ChartAreas[0].AxisY.Interval = 5; // Ajuste de intervalo do eixo Y para melhor visualização
        }







        private void timer1_Tick(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;";
            AtualizarGraficoPizza(connectionString);
            AtualizarGraficoColuna(connectionString);
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblFundoControleDeEstoque_Click(object sender, EventArgs e)
        {

        }

        private void btnVoltarTelaInicial2_Click(object sender, EventArgs e)
        {
            TelaDeGerenciamento telaDeGerenciamento = new TelaDeGerenciamento();
            telaDeGerenciamento.WindowState = FormWindowState.Maximized;
            telaDeGerenciamento.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            telaDeGerenciamento.Show();

            this.FormClosed += (s, args) => telaDeGerenciamento.Show();
        }

        private void chart3_Click(object sender, EventArgs e)
        {

        }
    }
}
