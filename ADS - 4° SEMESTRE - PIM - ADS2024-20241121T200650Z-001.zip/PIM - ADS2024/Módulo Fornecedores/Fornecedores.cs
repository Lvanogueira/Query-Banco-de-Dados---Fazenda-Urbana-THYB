﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM_DESKTOP_TESTE01
{
    public partial class Fornecedores : Form
    {
        public Fornecedores()
        {
            InitializeComponent();
            CarregarProdutos();
            CarregarFornecedores();
            dataGridView2.SelectionChanged += new EventHandler(dataGridView2_SelectionChanged);
            dataGridView3.SelectionChanged += new EventHandler(dataGridView3_SelectionChanged);
        }

        SqlConnection cn = new SqlConnection(@"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;");
        SqlCommand cm = new SqlCommand(); //Comando para enviar instruções para o Banco de Dados 
        SqlDataReader dt; //Comando usado para receber dados de um select no Banco de Dados. (Leitor de Dados)

        private void CarregarProdutos()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(@"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;"))
                {
                    cn.Open();
                    string strSQL = "SELECT IdProduto, Nome, PrecoProduto, QuantidadeDeProdutos, DescricaoProduto FROM CadastroDeProdutos";
                    SqlDataAdapter da = new SqlDataAdapter(strSQL, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView2.DataSource = dt;
                }
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }

        private void CarregarFornecedores()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(@"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;"))
                {
                    cn.Open();
                    string strSQL = "SELECT IdFornecedor, Nome, Telefone, Email, Material, QuantidadeMaterial FROM Fornecedores";
                    SqlDataAdapter da = new SqlDataAdapter(strSQL, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView3.DataSource = dt;
                }
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }
        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0) // Verifica se há alguma linha selecionada
            {
                // Pega a linha selecionada
                DataGridViewRow row = dataGridView2.SelectedRows[0];

                // Preenche os campos com os valores da linha selecionada
                txtNomeProduto3.Text = row.Cells["Nome"].Value.ToString();
                mskPrecoProduto3.Text = row.Cells["PrecoProduto"].Value.ToString();
                mskQuantidadeDeProdutos3.Text = row.Cells["QuantidadeDeProdutos"].Value.ToString();
                txtDescricaoProduto3.Text = row.Cells["DescricaoProduto"].Value.ToString();
            }
        }
        private void dataGridView3_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView3.SelectedRows.Count > 0) // Verifica se há alguma linha selecionada
            {
                // Pega a linha selecionada
                DataGridViewRow row = dataGridView3.SelectedRows[0];

                // Preenche os campos com os valores da linha selecionada
                txtNomeFornecedor.Text = row.Cells["Nome"].Value.ToString();
                txtTelefoneFornecedor.Text = row.Cells["Telefone"].Value.ToString();
                txtEmailFornecedor.Text = row.Cells["Email"].Value.ToString();
                txtMaterialDoFornecedor.Text = row.Cells["Material"].Value.ToString();
            }
        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
  
        }
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica se há uma linha válida selecionada
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];

                // Preenche os campos de texto com os dados da linha selecionada
                txtNomeProduto3.Text = row.Cells["Nome"].Value.ToString();
                mskPrecoProduto3.Text = row.Cells["PrecoProduto"].Value.ToString();
                mskQuantidadeDeProdutos3.Text = row.Cells["QuantidadeDeProdutos"].Value.ToString();
                txtDescricaoProduto3.Text = row.Cells["DescricaoProduto"].Value.ToString();
            }
        }
        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica se há uma linha válida selecionada
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView3.Rows[e.RowIndex];

                // Preenche os campos de texto com os dados da linha selecionada
                txtNomeFornecedor.Text = row.Cells["Nome"].Value.ToString();
                txtTelefoneFornecedor.Text = row.Cells["Telefone"].Value.ToString();
                txtEmailFornecedor.Text = row.Cells["Email"].Value.ToString();
                txtMaterialDoFornecedor.Text = row.Cells["Material"].Value.ToString();
            }
        }

        private void txtDescricaoProduto3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVoltarTelaInicial3_Click(object sender, EventArgs e)
        {
            ControledeEstoque controledeEstoque = new ControledeEstoque();
            controledeEstoque.WindowState = FormWindowState.Maximized;
            controledeEstoque.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            controledeEstoque.Show();

            this.FormClosed += (s, args) => controledeEstoque.Show();
        }

        private void lblNomeProduto3_Click(object sender, EventArgs e)
        {

        }

        private void lblFundoFornecedores_Click(object sender, EventArgs e)
        {

        }

        private void txtNomeProduto3_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPrecoProduto3_Click(object sender, EventArgs e)
        {

        }

        private void lblQuantidadeItens3_Click(object sender, EventArgs e)
        {

        }

        private void mskQuantidadeDeProdutos3_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblDescriçãodoProduto3_Click(object sender, EventArgs e)
        {

        }

        private void lblIdProduto_Click(object sender, EventArgs e)
        {

        }

        private void txtIdProduto3_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblListaDeProdutos_Click(object sender, EventArgs e)
        {

        }

        private void mskPrecoProduto3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMaterialDoFornecedor_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuantidadeSolicitada_TextChanged(object sender, EventArgs e)
        {

        }

        private void Fornecedores_Load(object sender, EventArgs e)
        {

        }

        private void btnSolicitar_Click(object sender, EventArgs e)
        {
            try
            {
                int quantidadeSolicitada = int.Parse(txtQuantidadeSolicitada.Text);
                int idFornecedor = int.Parse(dataGridView3.SelectedRows[0].Cells["IdFornecedor"].Value.ToString());
                int idProduto = int.Parse(dataGridView2.SelectedRows[0].Cells["IdProduto"].Value.ToString());

                using (SqlConnection cn = new SqlConnection(@"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;"))
                {
                    cn.Open();
                    SqlTransaction transaction = cn.BeginTransaction();

                    string queryFornecedor = @"
                    UPDATE Fornecedores 
                    SET QuantidadeMaterial = QuantidadeMaterial - @QuantidadeSolicitada 
                    WHERE IdFornecedor = @IdFornecedor";

                    string queryProduto = @"
                    UPDATE CadastroDeProdutos 
                    SET QuantidadeDeProdutos = QuantidadeDeProdutos + @QuantidadeSolicitada 
                    WHERE IdProduto = @IdProduto";

                    using (SqlCommand cmdFornecedor = new SqlCommand(queryFornecedor, cn, transaction))
                    {
                        cmdFornecedor.Parameters.AddWithValue("@QuantidadeSolicitada", quantidadeSolicitada);
                        cmdFornecedor.Parameters.AddWithValue("@IdFornecedor", idFornecedor);
                        cmdFornecedor.ExecuteNonQuery();
                    }

                    using (SqlCommand cmdProduto = new SqlCommand(queryProduto, cn, transaction))
                    {
                        cmdProduto.Parameters.AddWithValue("@QuantidadeSolicitada", quantidadeSolicitada);
                        cmdProduto.Parameters.AddWithValue("@IdProduto", idProduto);
                        cmdProduto.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Solicitação realizada com sucesso!");

                    CarregarFornecedores();
                    CarregarProdutos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao realizar a solicitação: " + ex.Message);
            }
        }
    }

}
