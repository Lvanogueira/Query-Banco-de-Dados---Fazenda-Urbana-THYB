﻿namespace PIM_DESKTOP_TESTE01
{
    partial class Fornecedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnVoltarTelaInicial3 = new System.Windows.Forms.Button();
            this.lblFundoFornecedores = new System.Windows.Forms.Label();
            this.lblDivisao3 = new System.Windows.Forms.Label();
            this.txtNomeProduto3 = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtDescricaoProduto3 = new System.Windows.Forms.TextBox();
            this.lblDescriçãodoProduto3 = new System.Windows.Forms.Label();
            this.mskQuantidadeDeProdutos3 = new System.Windows.Forms.TextBox();
            this.lblQuantidadeItens3 = new System.Windows.Forms.Label();
            this.mskPrecoProduto3 = new System.Windows.Forms.TextBox();
            this.lblPrecoProduto3 = new System.Windows.Forms.Label();
            this.lblNomeProduto3 = new System.Windows.Forms.Label();
            this.lblListaDeProdutos = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.lblListaDeFornecedores = new System.Windows.Forms.Label();
            this.txtNomeFornecedor = new System.Windows.Forms.TextBox();
            this.txtMaterialDoFornecedor = new System.Windows.Forms.TextBox();
            this.lblMaterialDoFornecedor = new System.Windows.Forms.Label();
            this.txtEmailFornecedor = new System.Windows.Forms.TextBox();
            this.lblEmailFornecedor = new System.Windows.Forms.Label();
            this.txtTelefoneFornecedor = new System.Windows.Forms.TextBox();
            this.lblTelefoneFornecedor = new System.Windows.Forms.Label();
            this.lblNomeFornecedor = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblQuantidadeSolicitada = new System.Windows.Forms.Label();
            this.txtQuantidadeSolicitada = new System.Windows.Forms.TextBox();
            this.btnSolicitar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.CausesValidation = false;
            this.label1.Location = new System.Drawing.Point(277, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 0;
            // 
            // btnVoltarTelaInicial3
            // 
            this.btnVoltarTelaInicial3.BackColor = System.Drawing.Color.SeaGreen;
            this.btnVoltarTelaInicial3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltarTelaInicial3.ForeColor = System.Drawing.Color.White;
            this.btnVoltarTelaInicial3.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.home_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnVoltarTelaInicial3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVoltarTelaInicial3.Location = new System.Drawing.Point(-1, 43);
            this.btnVoltarTelaInicial3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVoltarTelaInicial3.Name = "btnVoltarTelaInicial3";
            this.btnVoltarTelaInicial3.Size = new System.Drawing.Size(533, 70);
            this.btnVoltarTelaInicial3.TabIndex = 16;
            this.btnVoltarTelaInicial3.Text = "Voltar para Controle de Estoque.";
            this.btnVoltarTelaInicial3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVoltarTelaInicial3.UseVisualStyleBackColor = false;
            this.btnVoltarTelaInicial3.Click += new System.EventHandler(this.btnVoltarTelaInicial3_Click);
            // 
            // lblFundoFornecedores
            // 
            this.lblFundoFornecedores.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundoFornecedores.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFundoFornecedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoFornecedores.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblFundoFornecedores.Location = new System.Drawing.Point(227, 124);
            this.lblFundoFornecedores.Name = "lblFundoFornecedores";
            this.lblFundoFornecedores.Size = new System.Drawing.Size(1602, 843);
            this.lblFundoFornecedores.TabIndex = 15;
            this.lblFundoFornecedores.Click += new System.EventHandler(this.lblFundoFornecedores_Click);
            // 
            // lblDivisao3
            // 
            this.lblDivisao3.BackColor = System.Drawing.Color.LightGreen;
            this.lblDivisao3.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblDivisao3.Location = new System.Drawing.Point(1026, 140);
            this.lblDivisao3.Name = "lblDivisao3";
            this.lblDivisao3.Size = new System.Drawing.Size(10, 625);
            this.lblDivisao3.TabIndex = 19;
            this.lblDivisao3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtNomeProduto3
            // 
            this.txtNomeProduto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeProduto3.Location = new System.Drawing.Point(464, 415);
            this.txtNomeProduto3.Multiline = true;
            this.txtNomeProduto3.Name = "txtNomeProduto3";
            this.txtNomeProduto3.Size = new System.Drawing.Size(357, 57);
            this.txtNomeProduto3.TabIndex = 52;
            this.txtNomeProduto3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNomeProduto3.TextChanged += new System.EventHandler(this.txtNomeProduto3_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(299, 255);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(671, 109);
            this.dataGridView2.TabIndex = 51;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // txtDescricaoProduto3
            // 
            this.txtDescricaoProduto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtDescricaoProduto3.Location = new System.Drawing.Point(406, 693);
            this.txtDescricaoProduto3.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescricaoProduto3.Multiline = true;
            this.txtDescricaoProduto3.Name = "txtDescricaoProduto3";
            this.txtDescricaoProduto3.Size = new System.Drawing.Size(447, 72);
            this.txtDescricaoProduto3.TabIndex = 50;
            this.txtDescricaoProduto3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDescricaoProduto3.TextChanged += new System.EventHandler(this.txtDescricaoProduto3_TextChanged);
            // 
            // lblDescriçãodoProduto3
            // 
            this.lblDescriçãodoProduto3.BackColor = System.Drawing.Color.SeaGreen;
            this.lblDescriçãodoProduto3.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblDescriçãodoProduto3.Location = new System.Drawing.Point(468, 650);
            this.lblDescriçãodoProduto3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriçãodoProduto3.Name = "lblDescriçãodoProduto3";
            this.lblDescriçãodoProduto3.Size = new System.Drawing.Size(349, 39);
            this.lblDescriçãodoProduto3.TabIndex = 49;
            this.lblDescriçãodoProduto3.Text = "Descrição do Produto";
            this.lblDescriçãodoProduto3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDescriçãodoProduto3.Click += new System.EventHandler(this.lblDescriçãodoProduto3_Click);
            // 
            // mskQuantidadeDeProdutos3
            // 
            this.mskQuantidadeDeProdutos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.mskQuantidadeDeProdutos3.Location = new System.Drawing.Point(464, 610);
            this.mskQuantidadeDeProdutos3.Margin = new System.Windows.Forms.Padding(4);
            this.mskQuantidadeDeProdutos3.Multiline = true;
            this.mskQuantidadeDeProdutos3.Name = "mskQuantidadeDeProdutos3";
            this.mskQuantidadeDeProdutos3.Size = new System.Drawing.Size(353, 36);
            this.mskQuantidadeDeProdutos3.TabIndex = 48;
            this.mskQuantidadeDeProdutos3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskQuantidadeDeProdutos3.TextChanged += new System.EventHandler(this.mskQuantidadeDeProdutos3_TextChanged);
            // 
            // lblQuantidadeItens3
            // 
            this.lblQuantidadeItens3.BackColor = System.Drawing.Color.SeaGreen;
            this.lblQuantidadeItens3.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblQuantidadeItens3.Location = new System.Drawing.Point(468, 575);
            this.lblQuantidadeItens3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuantidadeItens3.Name = "lblQuantidadeItens3";
            this.lblQuantidadeItens3.Size = new System.Drawing.Size(349, 31);
            this.lblQuantidadeItens3.TabIndex = 47;
            this.lblQuantidadeItens3.Text = "Quantidade de Itens";
            this.lblQuantidadeItens3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQuantidadeItens3.Click += new System.EventHandler(this.lblQuantidadeItens3_Click);
            // 
            // mskPrecoProduto3
            // 
            this.mskPrecoProduto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.mskPrecoProduto3.Location = new System.Drawing.Point(464, 523);
            this.mskPrecoProduto3.Margin = new System.Windows.Forms.Padding(4);
            this.mskPrecoProduto3.Multiline = true;
            this.mskPrecoProduto3.Name = "mskPrecoProduto3";
            this.mskPrecoProduto3.Size = new System.Drawing.Size(353, 34);
            this.mskPrecoProduto3.TabIndex = 46;
            this.mskPrecoProduto3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskPrecoProduto3.TextChanged += new System.EventHandler(this.mskPrecoProduto3_TextChanged);
            // 
            // lblPrecoProduto3
            // 
            this.lblPrecoProduto3.AutoSize = true;
            this.lblPrecoProduto3.BackColor = System.Drawing.Color.SeaGreen;
            this.lblPrecoProduto3.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblPrecoProduto3.Location = new System.Drawing.Point(504, 485);
            this.lblPrecoProduto3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrecoProduto3.Name = "lblPrecoProduto3";
            this.lblPrecoProduto3.Size = new System.Drawing.Size(267, 34);
            this.lblPrecoProduto3.TabIndex = 45;
            this.lblPrecoProduto3.Text = "Preço do Produto";
            this.lblPrecoProduto3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPrecoProduto3.Click += new System.EventHandler(this.lblPrecoProduto3_Click);
            // 
            // lblNomeProduto3
            // 
            this.lblNomeProduto3.AutoSize = true;
            this.lblNomeProduto3.BackColor = System.Drawing.Color.SeaGreen;
            this.lblNomeProduto3.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProduto3.Location = new System.Drawing.Point(504, 378);
            this.lblNomeProduto3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeProduto3.Name = "lblNomeProduto3";
            this.lblNomeProduto3.Size = new System.Drawing.Size(273, 34);
            this.lblNomeProduto3.TabIndex = 44;
            this.lblNomeProduto3.Text = "Nome do Produto";
            this.lblNomeProduto3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNomeProduto3.Click += new System.EventHandler(this.lblNomeProduto3_Click);
            // 
            // lblListaDeProdutos
            // 
            this.lblListaDeProdutos.BackColor = System.Drawing.Color.SeaGreen;
            this.lblListaDeProdutos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblListaDeProdutos.Font = new System.Drawing.Font("Lucida Sans", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListaDeProdutos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblListaDeProdutos.Location = new System.Drawing.Point(468, 140);
            this.lblListaDeProdutos.Name = "lblListaDeProdutos";
            this.lblListaDeProdutos.Size = new System.Drawing.Size(353, 92);
            this.lblListaDeProdutos.TabIndex = 43;
            this.lblListaDeProdutos.Text = "Lista de Produtos";
            this.lblListaDeProdutos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblListaDeProdutos.Click += new System.EventHandler(this.lblListaDeProdutos_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToOrderColumns = true;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(1087, 255);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(671, 109);
            this.dataGridView3.TabIndex = 54;
            // 
            // lblListaDeFornecedores
            // 
            this.lblListaDeFornecedores.BackColor = System.Drawing.Color.SeaGreen;
            this.lblListaDeFornecedores.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblListaDeFornecedores.Font = new System.Drawing.Font("Lucida Sans", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListaDeFornecedores.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblListaDeFornecedores.Location = new System.Drawing.Point(1210, 140);
            this.lblListaDeFornecedores.Name = "lblListaDeFornecedores";
            this.lblListaDeFornecedores.Size = new System.Drawing.Size(461, 92);
            this.lblListaDeFornecedores.TabIndex = 53;
            this.lblListaDeFornecedores.Text = "Lista de Fornecedores";
            this.lblListaDeFornecedores.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNomeFornecedor
            // 
            this.txtNomeFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeFornecedor.Location = new System.Drawing.Point(1150, 415);
            this.txtNomeFornecedor.Multiline = true;
            this.txtNomeFornecedor.Name = "txtNomeFornecedor";
            this.txtNomeFornecedor.Size = new System.Drawing.Size(521, 57);
            this.txtNomeFornecedor.TabIndex = 62;
            this.txtNomeFornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMaterialDoFornecedor
            // 
            this.txtMaterialDoFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtMaterialDoFornecedor.Location = new System.Drawing.Point(1150, 693);
            this.txtMaterialDoFornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterialDoFornecedor.Multiline = true;
            this.txtMaterialDoFornecedor.Name = "txtMaterialDoFornecedor";
            this.txtMaterialDoFornecedor.Size = new System.Drawing.Size(521, 72);
            this.txtMaterialDoFornecedor.TabIndex = 61;
            this.txtMaterialDoFornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMaterialDoFornecedor.TextChanged += new System.EventHandler(this.txtMaterialDoFornecedor_TextChanged);
            // 
            // lblMaterialDoFornecedor
            // 
            this.lblMaterialDoFornecedor.BackColor = System.Drawing.Color.SeaGreen;
            this.lblMaterialDoFornecedor.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblMaterialDoFornecedor.Location = new System.Drawing.Point(1194, 650);
            this.lblMaterialDoFornecedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaterialDoFornecedor.Name = "lblMaterialDoFornecedor";
            this.lblMaterialDoFornecedor.Size = new System.Drawing.Size(442, 39);
            this.lblMaterialDoFornecedor.TabIndex = 60;
            this.lblMaterialDoFornecedor.Text = "Material do Fornecedor";
            this.lblMaterialDoFornecedor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEmailFornecedor
            // 
            this.txtEmailFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtEmailFornecedor.Location = new System.Drawing.Point(1150, 610);
            this.txtEmailFornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmailFornecedor.Multiline = true;
            this.txtEmailFornecedor.Name = "txtEmailFornecedor";
            this.txtEmailFornecedor.Size = new System.Drawing.Size(521, 36);
            this.txtEmailFornecedor.TabIndex = 59;
            this.txtEmailFornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblEmailFornecedor
            // 
            this.lblEmailFornecedor.BackColor = System.Drawing.Color.SeaGreen;
            this.lblEmailFornecedor.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblEmailFornecedor.Location = new System.Drawing.Point(1236, 575);
            this.lblEmailFornecedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmailFornecedor.Name = "lblEmailFornecedor";
            this.lblEmailFornecedor.Size = new System.Drawing.Size(349, 31);
            this.lblEmailFornecedor.TabIndex = 58;
            this.lblEmailFornecedor.Text = "E-mail do Fornecedor";
            this.lblEmailFornecedor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTelefoneFornecedor
            // 
            this.txtTelefoneFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtTelefoneFornecedor.Location = new System.Drawing.Point(1150, 523);
            this.txtTelefoneFornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.txtTelefoneFornecedor.Multiline = true;
            this.txtTelefoneFornecedor.Name = "txtTelefoneFornecedor";
            this.txtTelefoneFornecedor.Size = new System.Drawing.Size(521, 34);
            this.txtTelefoneFornecedor.TabIndex = 57;
            this.txtTelefoneFornecedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTelefoneFornecedor
            // 
            this.lblTelefoneFornecedor.AutoSize = true;
            this.lblTelefoneFornecedor.BackColor = System.Drawing.Color.SeaGreen;
            this.lblTelefoneFornecedor.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblTelefoneFornecedor.Location = new System.Drawing.Point(1236, 485);
            this.lblTelefoneFornecedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTelefoneFornecedor.Name = "lblTelefoneFornecedor";
            this.lblTelefoneFornecedor.Size = new System.Drawing.Size(367, 34);
            this.lblTelefoneFornecedor.TabIndex = 56;
            this.lblTelefoneFornecedor.Text = "Telefone do Fornecedor";
            this.lblTelefoneFornecedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeFornecedor
            // 
            this.lblNomeFornecedor.AutoSize = true;
            this.lblNomeFornecedor.BackColor = System.Drawing.Color.SeaGreen;
            this.lblNomeFornecedor.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFornecedor.Location = new System.Drawing.Point(1254, 378);
            this.lblNomeFornecedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeFornecedor.Name = "lblNomeFornecedor";
            this.lblNomeFornecedor.Size = new System.Drawing.Size(324, 34);
            this.lblNomeFornecedor.TabIndex = 55;
            this.lblNomeFornecedor.Text = "Nome do Fornecedor";
            this.lblNomeFornecedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightGreen;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.label2.Location = new System.Drawing.Point(299, 781);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1459, 10);
            this.label2.TabIndex = 63;
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblQuantidadeSolicitada
            // 
            this.lblQuantidadeSolicitada.BackColor = System.Drawing.Color.SeaGreen;
            this.lblQuantidadeSolicitada.Font = new System.Drawing.Font("Lucida Sans", 18F);
            this.lblQuantidadeSolicitada.Location = new System.Drawing.Point(801, 800);
            this.lblQuantidadeSolicitada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuantidadeSolicitada.Name = "lblQuantidadeSolicitada";
            this.lblQuantidadeSolicitada.Size = new System.Drawing.Size(442, 39);
            this.lblQuantidadeSolicitada.TabIndex = 64;
            this.lblQuantidadeSolicitada.Text = "Quantidade Solicitada";
            this.lblQuantidadeSolicitada.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQuantidadeSolicitada
            // 
            this.txtQuantidadeSolicitada.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.txtQuantidadeSolicitada.Location = new System.Drawing.Point(926, 843);
            this.txtQuantidadeSolicitada.Margin = new System.Windows.Forms.Padding(4);
            this.txtQuantidadeSolicitada.Multiline = true;
            this.txtQuantidadeSolicitada.Name = "txtQuantidadeSolicitada";
            this.txtQuantidadeSolicitada.Size = new System.Drawing.Size(211, 44);
            this.txtQuantidadeSolicitada.TabIndex = 65;
            this.txtQuantidadeSolicitada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQuantidadeSolicitada.TextChanged += new System.EventHandler(this.txtQuantidadeSolicitada_TextChanged);
            // 
            // btnSolicitar
            // 
            this.btnSolicitar.BackColor = System.Drawing.Color.Black;
            this.btnSolicitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitar.ForeColor = System.Drawing.SystemColors.Window;
            this.btnSolicitar.Location = new System.Drawing.Point(900, 894);
            this.btnSolicitar.Name = "btnSolicitar";
            this.btnSolicitar.Size = new System.Drawing.Size(258, 60);
            this.btnSolicitar.TabIndex = 66;
            this.btnSolicitar.Text = "Solicitar";
            this.btnSolicitar.UseVisualStyleBackColor = false;
            this.btnSolicitar.Click += new System.EventHandler(this.btnSolicitar_Click);
            // 
            // Fornecedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1917, 1055);
            this.Controls.Add(this.btnSolicitar);
            this.Controls.Add(this.txtQuantidadeSolicitada);
            this.Controls.Add(this.lblQuantidadeSolicitada);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNomeFornecedor);
            this.Controls.Add(this.txtMaterialDoFornecedor);
            this.Controls.Add(this.lblMaterialDoFornecedor);
            this.Controls.Add(this.txtEmailFornecedor);
            this.Controls.Add(this.lblEmailFornecedor);
            this.Controls.Add(this.txtTelefoneFornecedor);
            this.Controls.Add(this.lblTelefoneFornecedor);
            this.Controls.Add(this.lblNomeFornecedor);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.lblListaDeFornecedores);
            this.Controls.Add(this.txtNomeProduto3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.txtDescricaoProduto3);
            this.Controls.Add(this.lblDescriçãodoProduto3);
            this.Controls.Add(this.mskQuantidadeDeProdutos3);
            this.Controls.Add(this.lblQuantidadeItens3);
            this.Controls.Add(this.mskPrecoProduto3);
            this.Controls.Add(this.lblPrecoProduto3);
            this.Controls.Add(this.lblNomeProduto3);
            this.Controls.Add(this.lblListaDeProdutos);
            this.Controls.Add(this.lblDivisao3);
            this.Controls.Add(this.btnVoltarTelaInicial3);
            this.Controls.Add(this.lblFundoFornecedores);
            this.Controls.Add(this.label1);
            this.Name = "Fornecedores";
            this.Text = "Fornecedores";
            this.Load += new System.EventHandler(this.Fornecedores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVoltarTelaInicial3;
        private System.Windows.Forms.Label lblFundoFornecedores;
        private System.Windows.Forms.Label lblDivisao3;
        public System.Windows.Forms.TextBox txtNomeProduto3;
        private System.Windows.Forms.DataGridView dataGridView2;
        public System.Windows.Forms.TextBox txtDescricaoProduto3;
        public System.Windows.Forms.Label lblDescriçãodoProduto3;
        public System.Windows.Forms.TextBox mskQuantidadeDeProdutos3;
        public System.Windows.Forms.Label lblQuantidadeItens3;
        public System.Windows.Forms.TextBox mskPrecoProduto3;
        public System.Windows.Forms.Label lblPrecoProduto3;
        public System.Windows.Forms.Label lblNomeProduto3;
        public System.Windows.Forms.Label lblListaDeProdutos;
        private System.Windows.Forms.DataGridView dataGridView3;
        public System.Windows.Forms.Label lblListaDeFornecedores;
        public System.Windows.Forms.TextBox txtNomeFornecedor;
        public System.Windows.Forms.TextBox txtMaterialDoFornecedor;
        public System.Windows.Forms.Label lblMaterialDoFornecedor;
        public System.Windows.Forms.TextBox txtEmailFornecedor;
        public System.Windows.Forms.Label lblEmailFornecedor;
        public System.Windows.Forms.TextBox txtTelefoneFornecedor;
        public System.Windows.Forms.Label lblTelefoneFornecedor;
        public System.Windows.Forms.Label lblNomeFornecedor;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label lblQuantidadeSolicitada;
        public System.Windows.Forms.TextBox txtQuantidadeSolicitada;
        private System.Windows.Forms.Button btnSolicitar;
    }
}