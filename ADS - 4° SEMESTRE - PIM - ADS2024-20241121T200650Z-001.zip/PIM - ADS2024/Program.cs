﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM_DESKTOP_TESTE01
{
    internal static class Program
    {
        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Cria uma instância do formulário inicial (Form1)
            TelaInicial telaInicial = new TelaInicial();
            telaInicial.WindowState = FormWindowState.Maximized;
            telaInicial.FormBorderStyle = FormBorderStyle.None;

            // Exibe o formulário inicial
            Application.Run(telaInicial);
        }

    }
}
