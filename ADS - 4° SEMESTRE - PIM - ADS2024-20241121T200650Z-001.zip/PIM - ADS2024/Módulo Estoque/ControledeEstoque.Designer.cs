﻿namespace PIM_DESKTOP_TESTE01
{
    partial class ControledeEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGerenciamento = new System.Windows.Forms.Label();
            this.lblFundoControleDeEstoque = new System.Windows.Forms.Label();
            this.lblFundoLegenda = new System.Windows.Forms.Label();
            this.lblCorStatusRED = new System.Windows.Forms.Label();
            this.lblCorStatusYELLOW = new System.Windows.Forms.Label();
            this.lblCorStatusGREEN = new System.Windows.Forms.Label();
            this.lblLegendaRED = new System.Windows.Forms.Label();
            this.lblLegendaYELLOW = new System.Windows.Forms.Label();
            this.lblLegendaGREEN = new System.Windows.Forms.Label();
            this.lblListra = new System.Windows.Forms.Label();
            this.lblFundoAlface = new System.Windows.Forms.Label();
            this.lblNomeAlface = new System.Windows.Forms.Label();
            this.lblDescriçãoAlface = new System.Windows.Forms.Label();
            this.lblProdutoAlface = new System.Windows.Forms.Label();
            this.txtBoxAlfaceESTQ = new System.Windows.Forms.TextBox();
            this.btnSolicitarAlface = new System.Windows.Forms.Button();
            this.btnSolicitarTomate = new System.Windows.Forms.Button();
            this.txtBoxTomateESTQ = new System.Windows.Forms.TextBox();
            this.lblProdutoTomate = new System.Windows.Forms.Label();
            this.lblNomeTomate = new System.Windows.Forms.Label();
            this.lblFundoTomate = new System.Windows.Forms.Label();
            this.btnSolicitarCenoura = new System.Windows.Forms.Button();
            this.txtBoxCenouraESTQ = new System.Windows.Forms.TextBox();
            this.lblProdutoCenoura = new System.Windows.Forms.Label();
            this.lblNomeCenoura = new System.Windows.Forms.Label();
            this.lblDescriçãoCenoura = new System.Windows.Forms.Label();
            this.lblFundoCenoura = new System.Windows.Forms.Label();
            this.btnSolicitarBeringela = new System.Windows.Forms.Button();
            this.txtBoxBeringelaESTQ = new System.Windows.Forms.TextBox();
            this.lblProdutoBeringela = new System.Windows.Forms.Label();
            this.lblNomeBeringela = new System.Windows.Forms.Label();
            this.lblDescriçãoBeringela = new System.Windows.Forms.Label();
            this.lblFundoBeringela = new System.Windows.Forms.Label();
            this.btnSolicitarAbobora = new System.Windows.Forms.Button();
            this.txtBoxAboboraESTQ = new System.Windows.Forms.TextBox();
            this.lblProdutoAbobora = new System.Windows.Forms.Label();
            this.lblNomeAbobora = new System.Windows.Forms.Label();
            this.lblDescriçãoAbobora = new System.Windows.Forms.Label();
            this.lblFundoAbobora = new System.Windows.Forms.Label();
            this.btnSolicitarRepolhoRoxo = new System.Windows.Forms.Button();
            this.txtBoxRepolhoRoxoESTQ = new System.Windows.Forms.TextBox();
            this.lblProdutoRepolhoRoxo = new System.Windows.Forms.Label();
            this.lblNomeRepolhoRoxo = new System.Windows.Forms.Label();
            this.lblDescriçãoRepolhoRoxo = new System.Windows.Forms.Label();
            this.lblFundoRepolhoRoxo = new System.Windows.Forms.Label();
            this.lblDescriçãoTomate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.fotoRepolhoRoxo = new System.Windows.Forms.PictureBox();
            this.fotoAbobora = new System.Windows.Forms.PictureBox();
            this.fotoBeringela = new System.Windows.Forms.PictureBox();
            this.fotoCenoura = new System.Windows.Forms.PictureBox();
            this.fotoTomate = new System.Windows.Forms.PictureBox();
            this.fotoAlface = new System.Windows.Forms.PictureBox();
            this.btnVoltarTelaInicial2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fotoRepolhoRoxo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoAbobora)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoBeringela)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoCenoura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoTomate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoAlface)).BeginInit();
            this.SuspendLayout();
            // 
            // lblGerenciamento
            // 
            this.lblGerenciamento.BackColor = System.Drawing.Color.SeaGreen;
            this.lblGerenciamento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGerenciamento.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblGerenciamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGerenciamento.ForeColor = System.Drawing.Color.White;
            this.lblGerenciamento.Location = new System.Drawing.Point(708, 199);
            this.lblGerenciamento.Name = "lblGerenciamento";
            this.lblGerenciamento.Size = new System.Drawing.Size(415, 58);
            this.lblGerenciamento.TabIndex = 12;
            this.lblGerenciamento.Text = "Controle de Estoque";
            this.lblGerenciamento.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblGerenciamento.Click += new System.EventHandler(this.lblGerenciamento_Click);
            // 
            // lblFundoControleDeEstoque
            // 
            this.lblFundoControleDeEstoque.BackColor = System.Drawing.Color.SeaGreen;
            this.lblFundoControleDeEstoque.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFundoControleDeEstoque.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoControleDeEstoque.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblFundoControleDeEstoque.Location = new System.Drawing.Point(223, 178);
            this.lblFundoControleDeEstoque.Name = "lblFundoControleDeEstoque";
            this.lblFundoControleDeEstoque.Size = new System.Drawing.Size(1607, 786);
            this.lblFundoControleDeEstoque.TabIndex = 13;
            this.lblFundoControleDeEstoque.Click += new System.EventHandler(this.lblFundoControleDeEstoque_Click);
            // 
            // lblFundoLegenda
            // 
            this.lblFundoLegenda.BackColor = System.Drawing.Color.White;
            this.lblFundoLegenda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoLegenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoLegenda.Location = new System.Drawing.Point(1499, 199);
            this.lblFundoLegenda.Name = "lblFundoLegenda";
            this.lblFundoLegenda.Size = new System.Drawing.Size(297, 242);
            this.lblFundoLegenda.TabIndex = 15;
            this.lblFundoLegenda.Text = "Status do Estoque";
            this.lblFundoLegenda.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCorStatusRED
            // 
            this.lblCorStatusRED.BackColor = System.Drawing.Color.Red;
            this.lblCorStatusRED.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCorStatusRED.Location = new System.Drawing.Point(1519, 262);
            this.lblCorStatusRED.Name = "lblCorStatusRED";
            this.lblCorStatusRED.Size = new System.Drawing.Size(34, 29);
            this.lblCorStatusRED.TabIndex = 16;
            // 
            // lblCorStatusYELLOW
            // 
            this.lblCorStatusYELLOW.BackColor = System.Drawing.Color.Yellow;
            this.lblCorStatusYELLOW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCorStatusYELLOW.Location = new System.Drawing.Point(1519, 330);
            this.lblCorStatusYELLOW.Name = "lblCorStatusYELLOW";
            this.lblCorStatusYELLOW.Size = new System.Drawing.Size(34, 31);
            this.lblCorStatusYELLOW.TabIndex = 17;
            // 
            // lblCorStatusGREEN
            // 
            this.lblCorStatusGREEN.BackColor = System.Drawing.Color.Green;
            this.lblCorStatusGREEN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCorStatusGREEN.Location = new System.Drawing.Point(1519, 399);
            this.lblCorStatusGREEN.Name = "lblCorStatusGREEN";
            this.lblCorStatusGREEN.Size = new System.Drawing.Size(34, 31);
            this.lblCorStatusGREEN.TabIndex = 18;
            // 
            // lblLegendaRED
            // 
            this.lblLegendaRED.AutoSize = true;
            this.lblLegendaRED.BackColor = System.Drawing.Color.White;
            this.lblLegendaRED.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegendaRED.Location = new System.Drawing.Point(1559, 262);
            this.lblLegendaRED.Name = "lblLegendaRED";
            this.lblLegendaRED.Size = new System.Drawing.Size(186, 29);
            this.lblLegendaRED.TabIndex = 19;
            this.lblLegendaRED.Text = "0 à 49 Produtos.";
            // 
            // lblLegendaYELLOW
            // 
            this.lblLegendaYELLOW.BackColor = System.Drawing.Color.White;
            this.lblLegendaYELLOW.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegendaYELLOW.Location = new System.Drawing.Point(1559, 330);
            this.lblLegendaYELLOW.Name = "lblLegendaYELLOW";
            this.lblLegendaYELLOW.Size = new System.Drawing.Size(226, 31);
            this.lblLegendaYELLOW.TabIndex = 20;
            this.lblLegendaYELLOW.Text = "50 à 99 Produtos.";
            this.lblLegendaYELLOW.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblLegendaGREEN
            // 
            this.lblLegendaGREEN.BackColor = System.Drawing.Color.White;
            this.lblLegendaGREEN.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegendaGREEN.Location = new System.Drawing.Point(1559, 399);
            this.lblLegendaGREEN.Name = "lblLegendaGREEN";
            this.lblLegendaGREEN.Size = new System.Drawing.Size(226, 31);
            this.lblLegendaGREEN.TabIndex = 21;
            this.lblLegendaGREEN.Text = "+ de 99 Produtos.";
            // 
            // lblListra
            // 
            this.lblListra.BackColor = System.Drawing.Color.SeaGreen;
            this.lblListra.Location = new System.Drawing.Point(1499, 235);
            this.lblListra.Name = "lblListra";
            this.lblListra.Size = new System.Drawing.Size(297, 10);
            this.lblListra.TabIndex = 22;
            // 
            // lblFundoAlface
            // 
            this.lblFundoAlface.BackColor = System.Drawing.Color.White;
            this.lblFundoAlface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoAlface.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoAlface.Location = new System.Drawing.Point(357, 281);
            this.lblFundoAlface.Name = "lblFundoAlface";
            this.lblFundoAlface.Size = new System.Drawing.Size(344, 306);
            this.lblFundoAlface.TabIndex = 30;
            this.lblFundoAlface.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblFundoAlface.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblNomeAlface
            // 
            this.lblNomeAlface.BackColor = System.Drawing.Color.White;
            this.lblNomeAlface.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAlface.Location = new System.Drawing.Point(481, 286);
            this.lblNomeAlface.Name = "lblNomeAlface";
            this.lblNomeAlface.Size = new System.Drawing.Size(115, 26);
            this.lblNomeAlface.TabIndex = 34;
            this.lblNomeAlface.Text = "Alface";
            this.lblNomeAlface.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblNomeAlface.Click += new System.EventHandler(this.lblNomeAlface_Click);
            // 
            // lblDescriçãoAlface
            // 
            this.lblDescriçãoAlface.BackColor = System.Drawing.Color.White;
            this.lblDescriçãoAlface.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriçãoAlface.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDescriçãoAlface.Location = new System.Drawing.Point(372, 371);
            this.lblDescriçãoAlface.Name = "lblDescriçãoAlface";
            this.lblDescriçãoAlface.Size = new System.Drawing.Size(326, 108);
            this.lblDescriçãoAlface.TabIndex = 35;
            this.lblDescriçãoAlface.Text = "Alface verde fresca da fazenda urbana para suas saladas.";
            this.lblDescriçãoAlface.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblDescriçãoAlface.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // lblProdutoAlface
            // 
            this.lblProdutoAlface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdutoAlface.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoAlface.Location = new System.Drawing.Point(376, 480);
            this.lblProdutoAlface.Name = "lblProdutoAlface";
            this.lblProdutoAlface.Size = new System.Drawing.Size(309, 43);
            this.lblProdutoAlface.TabIndex = 37;
            this.lblProdutoAlface.Text = "Produtos no estoque:";
            this.lblProdutoAlface.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBoxAlfaceESTQ
            // 
            this.txtBoxAlfaceESTQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAlfaceESTQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBoxAlfaceESTQ.Location = new System.Drawing.Point(597, 487);
            this.txtBoxAlfaceESTQ.Multiline = true;
            this.txtBoxAlfaceESTQ.Name = "txtBoxAlfaceESTQ";
            this.txtBoxAlfaceESTQ.Size = new System.Drawing.Size(70, 27);
            this.txtBoxAlfaceESTQ.TabIndex = 38;
            this.txtBoxAlfaceESTQ.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnSolicitarAlface
            // 
            this.btnSolicitarAlface.BackColor = System.Drawing.Color.Black;
            this.btnSolicitarAlface.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitarAlface.ForeColor = System.Drawing.Color.White;
            this.btnSolicitarAlface.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSolicitarAlface.Location = new System.Drawing.Point(425, 526);
            this.btnSolicitarAlface.Name = "btnSolicitarAlface";
            this.btnSolicitarAlface.Size = new System.Drawing.Size(220, 43);
            this.btnSolicitarAlface.TabIndex = 39;
            this.btnSolicitarAlface.Text = "Solicitar Reposição";
            this.btnSolicitarAlface.UseVisualStyleBackColor = false;
            this.btnSolicitarAlface.Click += new System.EventHandler(this.btnSolicitarAlface_Click);
            // 
            // btnSolicitarTomate
            // 
            this.btnSolicitarTomate.BackColor = System.Drawing.Color.Black;
            this.btnSolicitarTomate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitarTomate.ForeColor = System.Drawing.Color.White;
            this.btnSolicitarTomate.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSolicitarTomate.Location = new System.Drawing.Point(794, 526);
            this.btnSolicitarTomate.Name = "btnSolicitarTomate";
            this.btnSolicitarTomate.Size = new System.Drawing.Size(220, 43);
            this.btnSolicitarTomate.TabIndex = 46;
            this.btnSolicitarTomate.Text = "Solicitar Reposição";
            this.btnSolicitarTomate.UseVisualStyleBackColor = false;
            this.btnSolicitarTomate.Click += new System.EventHandler(this.btnSolicitarTomate_Click);
            // 
            // txtBoxTomateESTQ
            // 
            this.txtBoxTomateESTQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxTomateESTQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBoxTomateESTQ.Location = new System.Drawing.Point(982, 482);
            this.txtBoxTomateESTQ.Multiline = true;
            this.txtBoxTomateESTQ.Name = "txtBoxTomateESTQ";
            this.txtBoxTomateESTQ.Size = new System.Drawing.Size(61, 27);
            this.txtBoxTomateESTQ.TabIndex = 45;
            // 
            // lblProdutoTomate
            // 
            this.lblProdutoTomate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdutoTomate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoTomate.Location = new System.Drawing.Point(761, 475);
            this.lblProdutoTomate.Name = "lblProdutoTomate";
            this.lblProdutoTomate.Size = new System.Drawing.Size(291, 43);
            this.lblProdutoTomate.TabIndex = 44;
            this.lblProdutoTomate.Text = "Produtos no estoque:";
            this.lblProdutoTomate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeTomate
            // 
            this.lblNomeTomate.BackColor = System.Drawing.Color.White;
            this.lblNomeTomate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeTomate.Location = new System.Drawing.Point(859, 286);
            this.lblNomeTomate.Name = "lblNomeTomate";
            this.lblNomeTomate.Size = new System.Drawing.Size(100, 26);
            this.lblNomeTomate.TabIndex = 41;
            this.lblNomeTomate.Text = "Tomate";
            this.lblNomeTomate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblFundoTomate
            // 
            this.lblFundoTomate.BackColor = System.Drawing.Color.White;
            this.lblFundoTomate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoTomate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoTomate.Location = new System.Drawing.Point(742, 281);
            this.lblFundoTomate.Name = "lblFundoTomate";
            this.lblFundoTomate.Size = new System.Drawing.Size(335, 300);
            this.lblFundoTomate.TabIndex = 40;
            this.lblFundoTomate.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnSolicitarCenoura
            // 
            this.btnSolicitarCenoura.BackColor = System.Drawing.Color.Black;
            this.btnSolicitarCenoura.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitarCenoura.ForeColor = System.Drawing.Color.White;
            this.btnSolicitarCenoura.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSolicitarCenoura.Location = new System.Drawing.Point(1187, 526);
            this.btnSolicitarCenoura.Name = "btnSolicitarCenoura";
            this.btnSolicitarCenoura.Size = new System.Drawing.Size(220, 43);
            this.btnSolicitarCenoura.TabIndex = 53;
            this.btnSolicitarCenoura.Text = "Solicitar Reposição";
            this.btnSolicitarCenoura.UseVisualStyleBackColor = false;
            this.btnSolicitarCenoura.Click += new System.EventHandler(this.btnSolicitarCenoura_Click);
            // 
            // txtBoxCenouraESTQ
            // 
            this.txtBoxCenouraESTQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxCenouraESTQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBoxCenouraESTQ.Location = new System.Drawing.Point(1365, 482);
            this.txtBoxCenouraESTQ.Multiline = true;
            this.txtBoxCenouraESTQ.Name = "txtBoxCenouraESTQ";
            this.txtBoxCenouraESTQ.Size = new System.Drawing.Size(61, 27);
            this.txtBoxCenouraESTQ.TabIndex = 52;
            // 
            // lblProdutoCenoura
            // 
            this.lblProdutoCenoura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdutoCenoura.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoCenoura.Location = new System.Drawing.Point(1144, 475);
            this.lblProdutoCenoura.Name = "lblProdutoCenoura";
            this.lblProdutoCenoura.Size = new System.Drawing.Size(291, 43);
            this.lblProdutoCenoura.TabIndex = 51;
            this.lblProdutoCenoura.Text = "Produtos no estoque:";
            this.lblProdutoCenoura.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeCenoura
            // 
            this.lblNomeCenoura.BackColor = System.Drawing.Color.White;
            this.lblNomeCenoura.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCenoura.Location = new System.Drawing.Point(1230, 286);
            this.lblNomeCenoura.Name = "lblNomeCenoura";
            this.lblNomeCenoura.Size = new System.Drawing.Size(122, 26);
            this.lblNomeCenoura.TabIndex = 48;
            this.lblNomeCenoura.Text = "Cenoura";
            this.lblNomeCenoura.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblDescriçãoCenoura
            // 
            this.lblDescriçãoCenoura.BackColor = System.Drawing.Color.White;
            this.lblDescriçãoCenoura.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriçãoCenoura.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDescriçãoCenoura.Location = new System.Drawing.Point(1129, 374);
            this.lblDescriçãoCenoura.Name = "lblDescriçãoCenoura";
            this.lblDescriçãoCenoura.Size = new System.Drawing.Size(326, 101);
            this.lblDescriçãoCenoura.TabIndex = 49;
            this.lblDescriçãoCenoura.Text = "Cenouras frescas e crocantes para suas receitas favoritas.";
            this.lblDescriçãoCenoura.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblFundoCenoura
            // 
            this.lblFundoCenoura.BackColor = System.Drawing.Color.White;
            this.lblFundoCenoura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoCenoura.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoCenoura.Location = new System.Drawing.Point(1125, 281);
            this.lblFundoCenoura.Name = "lblFundoCenoura";
            this.lblFundoCenoura.Size = new System.Drawing.Size(335, 300);
            this.lblFundoCenoura.TabIndex = 47;
            this.lblFundoCenoura.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnSolicitarBeringela
            // 
            this.btnSolicitarBeringela.BackColor = System.Drawing.Color.Black;
            this.btnSolicitarBeringela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitarBeringela.ForeColor = System.Drawing.Color.White;
            this.btnSolicitarBeringela.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSolicitarBeringela.Location = new System.Drawing.Point(1187, 843);
            this.btnSolicitarBeringela.Name = "btnSolicitarBeringela";
            this.btnSolicitarBeringela.Size = new System.Drawing.Size(220, 43);
            this.btnSolicitarBeringela.TabIndex = 60;
            this.btnSolicitarBeringela.Text = "Solicitar Reposição";
            this.btnSolicitarBeringela.UseVisualStyleBackColor = false;
            this.btnSolicitarBeringela.Click += new System.EventHandler(this.btnSolicitarBeringela_Click);
            // 
            // txtBoxBeringelaESTQ
            // 
            this.txtBoxBeringelaESTQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxBeringelaESTQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBoxBeringelaESTQ.Location = new System.Drawing.Point(1365, 799);
            this.txtBoxBeringelaESTQ.Multiline = true;
            this.txtBoxBeringelaESTQ.Name = "txtBoxBeringelaESTQ";
            this.txtBoxBeringelaESTQ.Size = new System.Drawing.Size(61, 27);
            this.txtBoxBeringelaESTQ.TabIndex = 59;
            // 
            // lblProdutoBeringela
            // 
            this.lblProdutoBeringela.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdutoBeringela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoBeringela.Location = new System.Drawing.Point(1144, 792);
            this.lblProdutoBeringela.Name = "lblProdutoBeringela";
            this.lblProdutoBeringela.Size = new System.Drawing.Size(291, 43);
            this.lblProdutoBeringela.TabIndex = 58;
            this.lblProdutoBeringela.Text = "Produtos no estoque:";
            this.lblProdutoBeringela.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeBeringela
            // 
            this.lblNomeBeringela.BackColor = System.Drawing.Color.White;
            this.lblNomeBeringela.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeBeringela.Location = new System.Drawing.Point(1230, 596);
            this.lblNomeBeringela.Name = "lblNomeBeringela";
            this.lblNomeBeringela.Size = new System.Drawing.Size(127, 30);
            this.lblNomeBeringela.TabIndex = 55;
            this.lblNomeBeringela.Text = "Beringela";
            this.lblNomeBeringela.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblDescriçãoBeringela
            // 
            this.lblDescriçãoBeringela.BackColor = System.Drawing.Color.White;
            this.lblDescriçãoBeringela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriçãoBeringela.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDescriçãoBeringela.Location = new System.Drawing.Point(1129, 683);
            this.lblDescriçãoBeringela.Name = "lblDescriçãoBeringela";
            this.lblDescriçãoBeringela.Size = new System.Drawing.Size(326, 101);
            this.lblDescriçãoBeringela.TabIndex = 56;
            this.lblDescriçãoBeringela.Text = "Alface verde fresca da fazenda urbana para suas saladas.";
            this.lblDescriçãoBeringela.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblFundoBeringela
            // 
            this.lblFundoBeringela.BackColor = System.Drawing.Color.White;
            this.lblFundoBeringela.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoBeringela.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoBeringela.Location = new System.Drawing.Point(1125, 595);
            this.lblFundoBeringela.Name = "lblFundoBeringela";
            this.lblFundoBeringela.Size = new System.Drawing.Size(335, 303);
            this.lblFundoBeringela.TabIndex = 54;
            this.lblFundoBeringela.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnSolicitarAbobora
            // 
            this.btnSolicitarAbobora.BackColor = System.Drawing.Color.Black;
            this.btnSolicitarAbobora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitarAbobora.ForeColor = System.Drawing.Color.White;
            this.btnSolicitarAbobora.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSolicitarAbobora.Location = new System.Drawing.Point(794, 843);
            this.btnSolicitarAbobora.Name = "btnSolicitarAbobora";
            this.btnSolicitarAbobora.Size = new System.Drawing.Size(220, 43);
            this.btnSolicitarAbobora.TabIndex = 67;
            this.btnSolicitarAbobora.Text = "Solicitar Reposição";
            this.btnSolicitarAbobora.UseVisualStyleBackColor = false;
            this.btnSolicitarAbobora.Click += new System.EventHandler(this.btnSolicitarAbobora_Click);
            // 
            // txtBoxAboboraESTQ
            // 
            this.txtBoxAboboraESTQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAboboraESTQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBoxAboboraESTQ.Location = new System.Drawing.Point(982, 799);
            this.txtBoxAboboraESTQ.Multiline = true;
            this.txtBoxAboboraESTQ.Name = "txtBoxAboboraESTQ";
            this.txtBoxAboboraESTQ.Size = new System.Drawing.Size(61, 27);
            this.txtBoxAboboraESTQ.TabIndex = 66;
            // 
            // lblProdutoAbobora
            // 
            this.lblProdutoAbobora.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdutoAbobora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoAbobora.Location = new System.Drawing.Point(761, 792);
            this.lblProdutoAbobora.Name = "lblProdutoAbobora";
            this.lblProdutoAbobora.Size = new System.Drawing.Size(291, 43);
            this.lblProdutoAbobora.TabIndex = 65;
            this.lblProdutoAbobora.Text = "Produtos no estoque:";
            this.lblProdutoAbobora.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeAbobora
            // 
            this.lblNomeAbobora.BackColor = System.Drawing.Color.White;
            this.lblNomeAbobora.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAbobora.Location = new System.Drawing.Point(859, 596);
            this.lblNomeAbobora.Name = "lblNomeAbobora";
            this.lblNomeAbobora.Size = new System.Drawing.Size(117, 26);
            this.lblNomeAbobora.TabIndex = 62;
            this.lblNomeAbobora.Text = "Abóbora";
            this.lblNomeAbobora.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblDescriçãoAbobora
            // 
            this.lblDescriçãoAbobora.BackColor = System.Drawing.Color.White;
            this.lblDescriçãoAbobora.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriçãoAbobora.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDescriçãoAbobora.Location = new System.Drawing.Point(775, 683);
            this.lblDescriçãoAbobora.Name = "lblDescriçãoAbobora";
            this.lblDescriçãoAbobora.Size = new System.Drawing.Size(268, 101);
            this.lblDescriçãoAbobora.TabIndex = 63;
            this.lblDescriçãoAbobora.Text = "Abóbora fresca e deliciosa para suas receitas.";
            this.lblDescriçãoAbobora.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblFundoAbobora
            // 
            this.lblFundoAbobora.BackColor = System.Drawing.Color.White;
            this.lblFundoAbobora.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoAbobora.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoAbobora.Location = new System.Drawing.Point(742, 595);
            this.lblFundoAbobora.Name = "lblFundoAbobora";
            this.lblFundoAbobora.Size = new System.Drawing.Size(335, 303);
            this.lblFundoAbobora.TabIndex = 61;
            this.lblFundoAbobora.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnSolicitarRepolhoRoxo
            // 
            this.btnSolicitarRepolhoRoxo.BackColor = System.Drawing.Color.Black;
            this.btnSolicitarRepolhoRoxo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolicitarRepolhoRoxo.ForeColor = System.Drawing.Color.White;
            this.btnSolicitarRepolhoRoxo.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSolicitarRepolhoRoxo.Location = new System.Drawing.Point(409, 843);
            this.btnSolicitarRepolhoRoxo.Name = "btnSolicitarRepolhoRoxo";
            this.btnSolicitarRepolhoRoxo.Size = new System.Drawing.Size(220, 43);
            this.btnSolicitarRepolhoRoxo.TabIndex = 74;
            this.btnSolicitarRepolhoRoxo.Text = "Solicitar Reposição";
            this.btnSolicitarRepolhoRoxo.UseVisualStyleBackColor = false;
            this.btnSolicitarRepolhoRoxo.Click += new System.EventHandler(this.btnSolicitarRepolhoRoxo_Click);
            // 
            // txtBoxRepolhoRoxoESTQ
            // 
            this.txtBoxRepolhoRoxoESTQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxRepolhoRoxoESTQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtBoxRepolhoRoxoESTQ.Location = new System.Drawing.Point(597, 799);
            this.txtBoxRepolhoRoxoESTQ.Multiline = true;
            this.txtBoxRepolhoRoxoESTQ.Name = "txtBoxRepolhoRoxoESTQ";
            this.txtBoxRepolhoRoxoESTQ.Size = new System.Drawing.Size(61, 27);
            this.txtBoxRepolhoRoxoESTQ.TabIndex = 73;
            // 
            // lblProdutoRepolhoRoxo
            // 
            this.lblProdutoRepolhoRoxo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdutoRepolhoRoxo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoRepolhoRoxo.Location = new System.Drawing.Point(376, 792);
            this.lblProdutoRepolhoRoxo.Name = "lblProdutoRepolhoRoxo";
            this.lblProdutoRepolhoRoxo.Size = new System.Drawing.Size(291, 43);
            this.lblProdutoRepolhoRoxo.TabIndex = 72;
            this.lblProdutoRepolhoRoxo.Text = "Produtos no estoque:";
            this.lblProdutoRepolhoRoxo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeRepolhoRoxo
            // 
            this.lblNomeRepolhoRoxo.BackColor = System.Drawing.Color.White;
            this.lblNomeRepolhoRoxo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeRepolhoRoxo.Location = new System.Drawing.Point(451, 598);
            this.lblNomeRepolhoRoxo.Name = "lblNomeRepolhoRoxo";
            this.lblNomeRepolhoRoxo.Size = new System.Drawing.Size(168, 26);
            this.lblNomeRepolhoRoxo.TabIndex = 69;
            this.lblNomeRepolhoRoxo.Text = "Repolho Roxo";
            this.lblNomeRepolhoRoxo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblDescriçãoRepolhoRoxo
            // 
            this.lblDescriçãoRepolhoRoxo.BackColor = System.Drawing.Color.White;
            this.lblDescriçãoRepolhoRoxo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriçãoRepolhoRoxo.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDescriçãoRepolhoRoxo.Location = new System.Drawing.Point(390, 683);
            this.lblDescriçãoRepolhoRoxo.Name = "lblDescriçãoRepolhoRoxo";
            this.lblDescriçãoRepolhoRoxo.Size = new System.Drawing.Size(268, 101);
            this.lblDescriçãoRepolhoRoxo.TabIndex = 70;
            this.lblDescriçãoRepolhoRoxo.Text = "Repolho roxo fresco para realçar suas refeições.";
            this.lblDescriçãoRepolhoRoxo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblFundoRepolhoRoxo
            // 
            this.lblFundoRepolhoRoxo.BackColor = System.Drawing.Color.White;
            this.lblFundoRepolhoRoxo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFundoRepolhoRoxo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFundoRepolhoRoxo.Location = new System.Drawing.Point(357, 595);
            this.lblFundoRepolhoRoxo.Name = "lblFundoRepolhoRoxo";
            this.lblFundoRepolhoRoxo.Size = new System.Drawing.Size(344, 303);
            this.lblFundoRepolhoRoxo.TabIndex = 68;
            this.lblFundoRepolhoRoxo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblDescriçãoTomate
            // 
            this.lblDescriçãoTomate.BackColor = System.Drawing.Color.White;
            this.lblDescriçãoTomate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriçãoTomate.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDescriçãoTomate.Location = new System.Drawing.Point(757, 349);
            this.lblDescriçãoTomate.Name = "lblDescriçãoTomate";
            this.lblDescriçãoTomate.Size = new System.Drawing.Size(311, 126);
            this.lblDescriçãoTomate.TabIndex = 42;
            this.lblDescriçãoTomate.Text = "Tomates frescos e suculentos para todos os seus pratos.";
            this.lblDescriçãoTomate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SeaGreen;
            this.label1.Location = new System.Drawing.Point(1499, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 10);
            this.label1.TabIndex = 75;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.SeaGreen;
            this.label2.Location = new System.Drawing.Point(1499, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 10);
            this.label2.TabIndex = 76;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(1499, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 242);
            this.label3.TabIndex = 77;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(1786, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 242);
            this.label4.TabIndex = 78;
            // 
            // fotoRepolhoRoxo
            // 
            this.fotoRepolhoRoxo.BackColor = System.Drawing.Color.Black;
            this.fotoRepolhoRoxo.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.RepolhoRoxo;
            this.fotoRepolhoRoxo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fotoRepolhoRoxo.Location = new System.Drawing.Point(456, 627);
            this.fotoRepolhoRoxo.Name = "fotoRepolhoRoxo";
            this.fotoRepolhoRoxo.Size = new System.Drawing.Size(155, 117);
            this.fotoRepolhoRoxo.TabIndex = 71;
            this.fotoRepolhoRoxo.TabStop = false;
            // 
            // fotoAbobora
            // 
            this.fotoAbobora.BackColor = System.Drawing.Color.Black;
            this.fotoAbobora.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.abobora;
            this.fotoAbobora.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fotoAbobora.Location = new System.Drawing.Point(830, 623);
            this.fotoAbobora.Name = "fotoAbobora";
            this.fotoAbobora.Size = new System.Drawing.Size(155, 117);
            this.fotoAbobora.TabIndex = 64;
            this.fotoAbobora.TabStop = false;
            // 
            // fotoBeringela
            // 
            this.fotoBeringela.BackColor = System.Drawing.Color.Black;
            this.fotoBeringela.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.beringela;
            this.fotoBeringela.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fotoBeringela.Location = new System.Drawing.Point(1216, 627);
            this.fotoBeringela.Name = "fotoBeringela";
            this.fotoBeringela.Size = new System.Drawing.Size(155, 117);
            this.fotoBeringela.TabIndex = 57;
            this.fotoBeringela.TabStop = false;
            // 
            // fotoCenoura
            // 
            this.fotoCenoura.BackColor = System.Drawing.Color.Black;
            this.fotoCenoura.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.cenoura;
            this.fotoCenoura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fotoCenoura.Location = new System.Drawing.Point(1216, 314);
            this.fotoCenoura.Name = "fotoCenoura";
            this.fotoCenoura.Size = new System.Drawing.Size(155, 118);
            this.fotoCenoura.TabIndex = 50;
            this.fotoCenoura.TabStop = false;
            // 
            // fotoTomate
            // 
            this.fotoTomate.BackColor = System.Drawing.Color.Black;
            this.fotoTomate.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.Tomate;
            this.fotoTomate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fotoTomate.Location = new System.Drawing.Point(830, 314);
            this.fotoTomate.Name = "fotoTomate";
            this.fotoTomate.Size = new System.Drawing.Size(155, 118);
            this.fotoTomate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fotoTomate.TabIndex = 43;
            this.fotoTomate.TabStop = false;
            // 
            // fotoAlface
            // 
            this.fotoAlface.BackColor = System.Drawing.Color.Black;
            this.fotoAlface.BackgroundImage = global::PIM_DESKTOP_TESTE01.Properties.Resources.Alface;
            this.fotoAlface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fotoAlface.Location = new System.Drawing.Point(456, 314);
            this.fotoAlface.Name = "fotoAlface";
            this.fotoAlface.Size = new System.Drawing.Size(154, 118);
            this.fotoAlface.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fotoAlface.TabIndex = 36;
            this.fotoAlface.TabStop = false;
            this.fotoAlface.Click += new System.EventHandler(this.fotoAlface_Click);
            // 
            // btnVoltarTelaInicial2
            // 
            this.btnVoltarTelaInicial2.BackColor = System.Drawing.Color.SeaGreen;
            this.btnVoltarTelaInicial2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltarTelaInicial2.ForeColor = System.Drawing.Color.White;
            this.btnVoltarTelaInicial2.Image = global::PIM_DESKTOP_TESTE01.Properties.Resources.home_16dp_000000_FILL0_wght400_GRAD0_opsz20;
            this.btnVoltarTelaInicial2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVoltarTelaInicial2.Location = new System.Drawing.Point(1, 63);
            this.btnVoltarTelaInicial2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVoltarTelaInicial2.Name = "btnVoltarTelaInicial2";
            this.btnVoltarTelaInicial2.Size = new System.Drawing.Size(463, 70);
            this.btnVoltarTelaInicial2.TabIndex = 14;
            this.btnVoltarTelaInicial2.Text = "Voltar para Gerenciamento.";
            this.btnVoltarTelaInicial2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVoltarTelaInicial2.UseVisualStyleBackColor = false;
            this.btnVoltarTelaInicial2.Click += new System.EventHandler(this.btnVoltarTelaInicial2_Click);
            // 
            // ControledeEstoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1917, 1055);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSolicitarRepolhoRoxo);
            this.Controls.Add(this.txtBoxRepolhoRoxoESTQ);
            this.Controls.Add(this.lblProdutoRepolhoRoxo);
            this.Controls.Add(this.lblNomeRepolhoRoxo);
            this.Controls.Add(this.fotoRepolhoRoxo);
            this.Controls.Add(this.lblDescriçãoRepolhoRoxo);
            this.Controls.Add(this.lblFundoRepolhoRoxo);
            this.Controls.Add(this.btnSolicitarAbobora);
            this.Controls.Add(this.txtBoxAboboraESTQ);
            this.Controls.Add(this.lblProdutoAbobora);
            this.Controls.Add(this.lblNomeAbobora);
            this.Controls.Add(this.fotoAbobora);
            this.Controls.Add(this.lblDescriçãoAbobora);
            this.Controls.Add(this.lblFundoAbobora);
            this.Controls.Add(this.btnSolicitarBeringela);
            this.Controls.Add(this.txtBoxBeringelaESTQ);
            this.Controls.Add(this.lblProdutoBeringela);
            this.Controls.Add(this.lblNomeBeringela);
            this.Controls.Add(this.fotoBeringela);
            this.Controls.Add(this.lblDescriçãoBeringela);
            this.Controls.Add(this.lblFundoBeringela);
            this.Controls.Add(this.btnSolicitarCenoura);
            this.Controls.Add(this.txtBoxCenouraESTQ);
            this.Controls.Add(this.lblProdutoCenoura);
            this.Controls.Add(this.lblNomeCenoura);
            this.Controls.Add(this.fotoCenoura);
            this.Controls.Add(this.lblDescriçãoCenoura);
            this.Controls.Add(this.lblFundoCenoura);
            this.Controls.Add(this.btnSolicitarTomate);
            this.Controls.Add(this.txtBoxTomateESTQ);
            this.Controls.Add(this.lblProdutoTomate);
            this.Controls.Add(this.lblNomeTomate);
            this.Controls.Add(this.fotoTomate);
            this.Controls.Add(this.lblDescriçãoTomate);
            this.Controls.Add(this.lblFundoTomate);
            this.Controls.Add(this.btnSolicitarAlface);
            this.Controls.Add(this.txtBoxAlfaceESTQ);
            this.Controls.Add(this.lblProdutoAlface);
            this.Controls.Add(this.lblNomeAlface);
            this.Controls.Add(this.fotoAlface);
            this.Controls.Add(this.lblDescriçãoAlface);
            this.Controls.Add(this.lblFundoAlface);
            this.Controls.Add(this.lblListra);
            this.Controls.Add(this.lblLegendaGREEN);
            this.Controls.Add(this.lblLegendaYELLOW);
            this.Controls.Add(this.lblLegendaRED);
            this.Controls.Add(this.lblCorStatusGREEN);
            this.Controls.Add(this.lblCorStatusYELLOW);
            this.Controls.Add(this.lblCorStatusRED);
            this.Controls.Add(this.lblFundoLegenda);
            this.Controls.Add(this.btnVoltarTelaInicial2);
            this.Controls.Add(this.lblGerenciamento);
            this.Controls.Add(this.lblFundoControleDeEstoque);
            this.Name = "ControledeEstoque";
            this.Text = "Controle de Estoque";
            this.Load += new System.EventHandler(this.ControledeEstoque_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fotoRepolhoRoxo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoAbobora)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoBeringela)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoCenoura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoTomate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotoAlface)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGerenciamento;
        private System.Windows.Forms.Label lblFundoControleDeEstoque;
        private System.Windows.Forms.Button btnVoltarTelaInicial2;
        private System.Windows.Forms.Label lblFundoLegenda;
        private System.Windows.Forms.Label lblCorStatusRED;
        private System.Windows.Forms.Label lblCorStatusYELLOW;
        private System.Windows.Forms.Label lblCorStatusGREEN;
        private System.Windows.Forms.Label lblLegendaRED;
        private System.Windows.Forms.Label lblLegendaYELLOW;
        private System.Windows.Forms.Label lblLegendaGREEN;
        private System.Windows.Forms.Label lblListra;
        private System.Windows.Forms.Label lblFundoAlface;
        private System.Windows.Forms.Label lblNomeAlface;
        private System.Windows.Forms.Label lblDescriçãoAlface;
        private System.Windows.Forms.PictureBox fotoAlface;
        private System.Windows.Forms.Label lblProdutoAlface;
        private System.Windows.Forms.TextBox txtBoxAlfaceESTQ;
        private System.Windows.Forms.Button btnSolicitarAlface;
        private System.Windows.Forms.Button btnSolicitarTomate;
        private System.Windows.Forms.TextBox txtBoxTomateESTQ;
        private System.Windows.Forms.Label lblProdutoTomate;
        private System.Windows.Forms.Label lblNomeTomate;
        private System.Windows.Forms.PictureBox fotoTomate;
        private System.Windows.Forms.Label lblFundoTomate;
        private System.Windows.Forms.Button btnSolicitarCenoura;
        private System.Windows.Forms.TextBox txtBoxCenouraESTQ;
        private System.Windows.Forms.Label lblProdutoCenoura;
        private System.Windows.Forms.Label lblNomeCenoura;
        private System.Windows.Forms.PictureBox fotoCenoura;
        private System.Windows.Forms.Label lblDescriçãoCenoura;
        private System.Windows.Forms.Label lblFundoCenoura;
        private System.Windows.Forms.Button btnSolicitarBeringela;
        private System.Windows.Forms.TextBox txtBoxBeringelaESTQ;
        private System.Windows.Forms.Label lblProdutoBeringela;
        private System.Windows.Forms.Label lblNomeBeringela;
        private System.Windows.Forms.Label lblDescriçãoBeringela;
        private System.Windows.Forms.Label lblFundoBeringela;
        private System.Windows.Forms.Button btnSolicitarAbobora;
        private System.Windows.Forms.TextBox txtBoxAboboraESTQ;
        private System.Windows.Forms.Label lblProdutoAbobora;
        private System.Windows.Forms.Label lblNomeAbobora;
        private System.Windows.Forms.PictureBox fotoAbobora;
        private System.Windows.Forms.Label lblDescriçãoAbobora;
        private System.Windows.Forms.Label lblFundoAbobora;
        private System.Windows.Forms.Button btnSolicitarRepolhoRoxo;
        private System.Windows.Forms.TextBox txtBoxRepolhoRoxoESTQ;
        private System.Windows.Forms.Label lblProdutoRepolhoRoxo;
        private System.Windows.Forms.Label lblNomeRepolhoRoxo;
        private System.Windows.Forms.PictureBox fotoRepolhoRoxo;
        private System.Windows.Forms.Label lblDescriçãoRepolhoRoxo;
        private System.Windows.Forms.Label lblFundoRepolhoRoxo;
        private System.Windows.Forms.PictureBox fotoBeringela;
        private System.Windows.Forms.Label lblDescriçãoTomate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}