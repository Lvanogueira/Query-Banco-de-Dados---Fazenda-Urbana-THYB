﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM_DESKTOP_TESTE01
{
    public partial class ControledeEstoque : Form
    {
        private Timer timer;

        public ControledeEstoque()
        {
            InitializeComponent();

            // Configurar o Timer para atualizar os dados em tempo real
            timer = new Timer();
            timer.Interval = 5000; // Atualizar a cada 5 segundos
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        // Evento chamado a cada 5 segundos para atualizar os dados
        private void Timer_Tick(object sender, EventArgs e)
        {
            AtualizarDados();
        }


        // Método para buscar os dados do banco de dados e atualizar a interface
        private void AtualizarDados()
        {
            string connectionString = @"Data Source=MTZNOTFS058763\SQLEXPRESS;Initial Catalog=BD_PIM_FAZENDA_URBANA;Integrated Security=True;Encrypt=False;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT Nome, QuantidadeDeProdutos FROM CadastroDeProdutos";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string nomeProduto = reader["Nome"].ToString();
                        int quantidade = Convert.ToInt32(reader["QuantidadeDeProdutos"]);

                        AtualizarProduto(nomeProduto, quantidade);
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar os dados: " + ex.Message);
                }
            }
        }

        // Atualizar o produto com base no nome e na quantidade
        private void AtualizarProduto(string nomeProduto, int quantidade)
        {
            TextBox txtBox = null;
            Label lblStatus = null;

            // Atribui o TextBox correto com base no nome do produto
            switch (nomeProduto.ToLower())
            {
                case "alface":
                    txtBox = txtBoxAlfaceESTQ; // TextBox correspondente ao Alface
                    lblStatus = lblProdutoAlface; // Label correspondente ao Alface
                    break;
                case "tomate":
                    txtBox = txtBoxTomateESTQ;
                    lblStatus = lblProdutoTomate;
                    break;
                case "cenoura":
                    txtBox = txtBoxCenouraESTQ;
                    lblStatus = lblProdutoCenoura;
                    break;
                case "repolho roxo":
                    txtBox = txtBoxRepolhoRoxoESTQ;
                    lblStatus = lblProdutoRepolhoRoxo;
                    break;
                case "abóbora":
                    txtBox = txtBoxAboboraESTQ;
                    lblStatus = lblProdutoAbobora;
                    break;
                case "beringela":
                    txtBox = txtBoxBeringelaESTQ;
                    lblStatus = lblProdutoBeringela;
                    break;
            }

            // Atualizar os valores na TextBox e alterar a cor da Label conforme a quantidade
            if (txtBox != null && lblStatus != null)
            {
                txtBox.Text = quantidade.ToString(); // Atualiza a quantidade de produtos

                // Alterar a cor de fundo da Label conforme a quantidade de produtos
                if (quantidade <= 49)
                {
                    lblStatus.BackColor = Color.Red; // Menos de 50: Vermelho
                }
                else if (quantidade <= 99)
                {
                    lblStatus.BackColor = Color.Yellow; // 50 a 99: Amarelo
                }
                else
                {
                    lblStatus.BackColor = Color.Green; // Acima de 101: Verde
                }
            }
        }

        private void ControledeEstoque_Load(object sender, EventArgs e)
        {

        }
        private void btnVoltarTelaInicial2_Click(object sender, EventArgs e)
        {
            TelaDeGerenciamento telaDeGerenciamento = new TelaDeGerenciamento();
            telaDeGerenciamento.WindowState = FormWindowState.Maximized;
            telaDeGerenciamento.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            telaDeGerenciamento.Show();

            this.FormClosed += (s, args) => telaDeGerenciamento.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void lblFundoControleDeEstoque_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lblGerenciamento_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void fotoAlface_Click(object sender, EventArgs e)
        {

        }

        private void lblNomeAlface_Click(object sender, EventArgs e)
        {

        }

        private void btnSolicitarAlface_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedores = new Fornecedores();
            fornecedores.WindowState = FormWindowState.Maximized;
            fornecedores.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            fornecedores.Show();

            this.FormClosed += (s, args) => fornecedores.Show();
        }

        private void btnSolicitarTomate_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedores = new Fornecedores();
            fornecedores.WindowState = FormWindowState.Maximized;
            fornecedores.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            fornecedores.Show();

            this.FormClosed += (s, args) => fornecedores.Show();
        }

        private void btnSolicitarCenoura_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedores = new Fornecedores();
            fornecedores.WindowState = FormWindowState.Maximized;
            fornecedores.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            fornecedores.Show();

            this.FormClosed += (s, args) => fornecedores.Show();
        }

        private void btnSolicitarBeringela_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedores = new Fornecedores();
            fornecedores.WindowState = FormWindowState.Maximized;
            fornecedores.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            fornecedores.Show();

            this.FormClosed += (s, args) => fornecedores.Show();
        }

        private void btnSolicitarAbobora_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedores = new Fornecedores();
            fornecedores.WindowState = FormWindowState.Maximized;
            fornecedores.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            fornecedores.Show();

            this.FormClosed += (s, args) => fornecedores.Show();
        }

        private void btnSolicitarRepolhoRoxo_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedores = new Fornecedores();
            fornecedores.WindowState = FormWindowState.Maximized;
            fornecedores.FormBorderStyle = FormBorderStyle.None;

            this.Hide();
            fornecedores.Show();

            this.FormClosed += (s, args) => fornecedores.Show();
        }
    }
}
